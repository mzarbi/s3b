import os
import sys
import time
import datetime
import logging

logging.basicConfig(level=logging.DEBUG)

sys.path.append(r'D:\Apps\pycore')
from common.io import s3
from common.utils.file_logger import init_logger

sys.path.append(r'D:\Apps\pyamltm')
from settings import LOG_DIR, _get_s3_key_from_file_name, S3_PROJECT_D
from settings import DAILY, MONTHLY, ENV_PARAM, SHARE_DRIVE

init_logger(log_dir=LOG_DIR, process_name='AMLTransformationIngestion', loglevel_stdout=logging.INFO)


def _get_file_frequency(file_name):
    """
    Parses the file name and returns daily or monthly
    example of monthly file: CM_ZAF_TSD_V3_12_DEC_2018.csv
    example of daily file  : CM_ARE_TSD_V3_20220101.csv
    :param file_name: full path name:
    :return: Daily or Monthly
    """
    base_name = os.path.basename(file_name)
    year_date = base_name[-12:-4]
    try:
        datetime.datetime.strptime(year_date, '%Y%m%d')
        return DAILY
    except:
        return MONTHLY


def _ingest_stock_files(perimeter='CM'):
    """
    Ingest all files from AML IT share drive into S3 raw layer
    :return: None
    """
    thisdir = os.path.join(SHARE_DRIVE[ENV_PARAM], perimeter)
    logging.info('>>> ENV_PARAM: {}'.format(ENV_PARAM))
    logging.info('>>> thisdir  : {}'.format(thisdir))
    c = 0
    s3_project = S3_PROJECT_D[perimeter]
    logging.info('Use S3 project name:{}'.format(s3_project))
    s3_mgr = s3.S3Manager(s3_project, ENV_PARAM, 'raw')
    all_keys = []
    for r, d, f in os.walk(thisdir):
        for file in f:
            full_path = os.path.join(r, file)
            file_parts = full_path.split('\\')
            if len(file_parts) == 14:  # other data types (Account, Posting...)
                year, version, country, data_type, file_name = full_path.split('\\')[-5:]
                s3_key = _get_s3_key_from_file_name(perimeter, file, country, data_type, version)
                if s3_key:
                    all_keys.append(s3_key)
            elif len(file_parts) == 15:  # Alerts
                year, version, country, data_type, scenario, file_name = full_path.split('\\')[-6:]
                s3_key = _get_s3_key_from_file_name(perimeter, file, country, data_type, version, scenario)
                if s3_key:
                    all_keys.append(s3_key)
            else:
                continue
            c += 1

    logging.info('All keys {} vs {}'.format(len(all_keys), c))
    logging.info('Nbr of files to be uploaded: {}'.format(len(all_keys)))
    keys_for_ingestion = []
    for s3_key in all_keys:
        logging.info('Upload file with key: {}'.format(s3_key))
        keys_for_ingestion.append(s3_key[:-9])
        s3_mgr.upload_file(f, s3_key, compress=True, compress_in_memory=True)
        time.sleep(1)

    logging.info('Nbr keys_for_ingestion: {}'.format(len(keys_for_ingestion)))
    # generate_ingestion_file(keys_for_ingestion, perimeter)


def generate_ingestion_file(keys_for_ingestion, perimeter):
    ad_grps = ['UK LON USR_CIB_DATAHUB_AML_DATA_CM_ARE PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_ARG PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_AUS PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_AUT PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_BGR PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_BHR PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_BRA PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_CHE PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_CHN PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_CZE PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_DEU PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_DNK PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_ESP PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_GBR PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_HKG PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_HUN PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_IDN PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_IND PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_IRL PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_JPN PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_KOR PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_KWT PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_MYS PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_NLD PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_NOR PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_PRT PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_QAT PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_ROU PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_SAU PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_SGP PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_SWE PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_THA PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_TWN PRD', 'UK LON USR_CIB_DATAHUB_AML_DATA_CM_VNM PRD',
               'UK LON USR_CIB_DATAHUB_AML_DATA_CM_ZAF PRD']

    import pandas as pd
    df = pd.read_csv(r'D:\dev\git\datahub\pyamltm\deployment/ingestion.csv')
    print(df)
    dico = {}
    for k in keys_for_ingestion:
        parts = k.split('/')
        print(parts)
        entity, system_name, s3_obj_name = S3_PROJECT_D[perimeter].upper(), parts[0], '/'.join(parts[1:])
        ad_grp = get_ad_group(system_name, ad_grps)
        if not ad_grp:
            print('No AD group found for this key: {}'.format(k))
            sys.exit()

        key = '-'.join([entity, system_name, s3_obj_name])
        dico[key] = ad_grp
        print(k, '>>', entity, system_name, s3_obj_name, ad_grp)

    print('====================Dico: {} ===================='.format(len(dico)))
    keys = list(dico.keys())
    keys.sort()
    df2 = {'SRC_IDF_NAME': 'XXX',
           'SRC_FILE_PATH': 'AMLTM',
           'TRG_FILE_PATH': 'global_banking',
           'ENCD_TYPE': 'ISO-8859-1',
           'SRC_FILE_TYPE': 'delimited',
           'SRC_FILE_DT_FMT': '',
           'TRG_FILE_LAYER': 1,
           'PAR_COMP_TYPE': '',
           'SRC_FILE_DELIMITER': ',',
           'SRC_FILE_QUOTECHAR': '',
           'SRC_FILE_FORMAT': 'csv',
           'NBR_HEADER': 0,
           'NBR_FOOTER': 0,
           'IS_FILE_SENSITIVE': 1,
           'EMAIL': 'dl.datahub.core@bnpparibas.com',
           'DATA_OWNER_EMAIL': 'dl.datahub.core@bnpparibas.com',
           'SRC_FILE_RETEN_DAYS': 1000,
           'SRC_FILE_FREQ': 'DAILY',
           'SRC_FILE_ARRV_DAY': '',
           'SRC_FILE_MAX_ARRV_TIME': '07:00',
           'SRC_FILE_SIZE': '100',
           'SRC_DB_TYPE': '',
           'SRC_DB_INSTANCE': '',
           'IS_ACTIVE': 1,
           'IS_REFERENTIAL': 0,
           'TO_INGEST': 0,
           'APPLICATION': 'Data Hub',
           'INGESTION_TARGET_SYSTEM': '',
           'SRC_CHUNK_SIZE': '',
           'SRC_FILE_LOWER_MARGIN_LIMIT': '',
           'SRC_FILE_UPPER_MARGIN_LIMIT': '',
           'SRC_FILE_MAX_ROWS': '',
           'SRC_FILE_ALLOW_BAD_LINES': '',
           'SRC_CHECK_COL_ORDER': '',
           'SRC_CHECK_EXTRA_COLS': '',
           'SRC_CHECK_COL_CASE': '',
           'IS_ENCR_FLAG': 0,
           }
    for k in keys:
        ad_grp = dico[k]
        print(','.join([k, ad_grp]))
        entity, system_name, s3_obj_name, = k.split('-')
        df2['SRC_ENTITY'] = entity
        df2['SRC_NAME'] = system_name
        df2['S3_OBJ_NAME'] = s3_obj_name
        df2['SAILPOINT_ENTITLEMENT'] = ad_grp
        df2['SRC_SITE_NAME'] = system_name.split('_')[-1]
        df2['SRC_MSTR_FILE_NAME'] = s3_obj_name.split('/')[-1] + '*.csv'
        df2['SRC_FILE_NAME'] = system_name.split('_')[-1]
        df = df.append(df2, ignore_index=True)

    print(df)
    df.to_csv(r'D:\temp\AML_TM_ingestion.csv', index=False)


def get_ad_group(system_name, ad_grps):
    system_country_name = system_name[-3:]
    for g in ad_grps:
        country = g[-7:-4]
        #print('>>> get_ad_group:', country, ':', system_country_name)
        if country == system_country_name:
            return g

    return None


def main():
    _ingest_stock_files('CM')


if __name__ == '__main__':
    main()
