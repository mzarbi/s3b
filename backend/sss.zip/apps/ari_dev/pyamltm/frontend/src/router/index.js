import { createRouter, createWebHistory } from "vue-router";
import Dashboard from "@/views/dashboard/Dashboard.vue";
import FlowExplorer from "@/views/flow_explorer/FlowExplorer.vue";
import ArchiveExplorer from "@/views/archive_explorer/ArchiveExplorer.vue";
import AmlSettings from "@/views/aml_settings/AmlSettings.vue";
import NewFlowSettings from "@/views/new_flow_settings/NewFlowSettings.vue";
import Flow from "@/views/flow/Flow.vue";

const routes = [
  {
    path: "/",
    name: "/",
    redirect: "/dashboard",
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    component: Dashboard,
  },
  {
    path: "/flow-explorer",
    name: "Flow Explorer",
    component: FlowExplorer,
  },
  {
    path: "/archive-explorer",
    name: "Archive Explorer",
    component: ArchiveExplorer,
  },
  {
    path: "/flows/:uuid",
    name: "Flow",
    component: Flow,
  },
  {
    path: "/aml-settings",
    name: "AML Settings",
    component: AmlSettings,
  },
  {
    path: "/new-flow",
    name: "New Flow",
    component: NewFlowSettings,
  },

];

const router = createRouter({
  history: createWebHistory(process.env.NODE_ENV === 'production' ? document.baseURL : '/'),
  routes,
  linkActiveClass: "active",
});

export default router;

