<template>
  <sidenav
    :custom_class="this.$store.state.mcolor"
    :class="[
			this.$store.state.isTransparent,
			this.$store.state.isRTL ? 'fixed-end' : 'fixed-start'
		]"
    v-if="this.$store.state.showSidenav"
  />
  <main
    class="main-content position-relative max-height-vh-100 h-100 border-radius-lg"
    :style="this.$store.state.isRTL ? 'overflow-x: hidden' : ''"
  >
    <!-- nav -->
    <navbar
      :class="[navClasses]"
      :textWhite="this.$store.state.isAbsolute ? 'text-white opacity-8' : ''"
      :minNav="navbarMinimize"
      v-if="this.$store.state.showNavbar"
    />
    <router-view/>
    <app-footer v-show="this.$store.state.showFooter"/>
  </main>
  <GDialogRoot />
</template>
<script>
  import Sidenav from "@/views/ccmp/composite/Sidenav";
  import Navbar from "@/views/ccmp/composite/Navbars/Navbar.vue";
  import AppFooter from "@/views/ccmp/composite/Footer.vue";
  import {mapMutations} from "vuex";
  import axios from "axios";

  export default {
    name: "App",
    components: {
      Sidenav,
      Navbar,
      AppFooter
    },
    data() {
      return {
        status: null,
        pollInterval: null,
        sseClient: null,
        messages: []
      };
    },
    beforeUnmount() {
      this.sseClient.disconnect();
    },
    methods: {
      handleMessage(message, lastEventId) {
        alert('Received a message w/o an event!' + JSON.stringify(message));
      },
      ...mapMutations(["navbarMinimize"]),
      fetchNotifications() {
        const path = this.$store.state.backendUrl + "notifications";
        axios
          .get(path)
          .then(res => {
            console.log(res.data);
            const cswal = this.$swal.mixin({
              customClass: {
                title: "sa"
              },
              buttonsStyling: false
            });
            if (res.data.status == "SUCCESS") {
              cswal
                .fire({
                  position: "bottom-end",
                  icon: "success",
                  title: res.data.message,
                  showConfirmButton: false,
                  timer: 5000
                })
                .then(result => {
                  console.log(result);
                  this.$router.go(0);
                });
            } else if (res.data.status == "ERROR") {
              cswal
                .fire({
                  position: "bottom-end",
                  icon: "error",
                  title: res.data.message,
                  showConfirmButton: false,
                  timer: 20000
                })
                .then(result => {
                  console.log(result);
                  this.$router.go(0);
                });
            }
          })
          .catch(error => {
            console.error(error);
          });
      }
    },
    computed: {
      navClasses() {
        return {
          "position-sticky blur shadow-blur mt-4 left-auto top-1 z-index-sticky": this
            .$store.state.isNavFixed,
          "position-absolute px-4 mx-0 w-100 z-index-2": this.$store.state.isAbsolute,
          "px-0 mx-4 mt-4": !this.$store.state.isAbsolute
        };
      }
    },
    beforeMount() {
      this.$store.state.isTransparent = "bg-transparent";
    },
    created() {
      this.pollInterval = setInterval(() => {
        this.fetchNotifications();
      }, 10000);
    },
    mounted() {
      this.sseClient = this.$sse.create({
        url: "http://127.0.0.1:5000/amltm/api/",
        format: 'json',
        withCredentials: true,
        polyfill: true,
      });

      // Catch any errors (ie. lost connections, etc.)
      this.sseClient.on('error', (e) => {
        console.error('lost connection or failed to parse!', e);
      });

      // Handle messages without a specific event
      this.sseClient.on('message', this.handleMessage);

      this.sseClient.connect()
        .then(sse => {
          console.log('We\'re connected!');

          // Unsubscribes from event-less messages after 7 seconds
          setTimeout(() => {
            this.sseClient.off('message', this.handleMessage);
            console.log('Stopped listening to event-less messages!');
          }, 7000);
        })
        .catch((err) => {
          console.error('Failed to connect to server', err);
        });
    },
  };
</script>
<style>
  .sa {
    font-size: 20px !important;
  }

  .in {
    margin: 1em 0em 0.3em;
  }
</style>
