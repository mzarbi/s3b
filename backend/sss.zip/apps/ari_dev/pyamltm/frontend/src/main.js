/**
=========================================================
* Vue Soft UI Dashboard - v2.0.0
=========================================================

* Product Page: https://creative-tim.com/product/vue-soft-ui-dashboard
* Copyright 2022 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

import { createApp } from "vue";
import App from "./App.vue";
import store from "./store";
import router from "./router";
import "./assets/css/nucleo-icons.css";
import "./assets/css/nucleo-svg.css";
import SoftUIDashboard from "./soft-ui-dashboard";
import SimpleTypeahead from 'vue3-simple-typeahead';
import 'vue3-simple-typeahead/dist/vue3-simple-typeahead.css';
import VueSweetalert2 from 'vue-sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';
import VueSSE from './server-sent-events/vue-sse'
import './third-parties/ccmp/gdialog/style.css'
import { GDialog } from './third-parties/ccmp/gdialog/index'
import { plugin as dialogPlugin } from './third-parties/ccmp/gdialog/index'



const appInstance = createApp(App);
appInstance.component('GDialog', GDialog)
appInstance.use(dialogPlugin, {
    // options
})
appInstance.use(VueSweetalert2);
appInstance.use(store);
appInstance.use(router);
appInstance.use(SoftUIDashboard);
appInstance.use(SimpleTypeahead);
appInstance.use(VueSSE);
appInstance.mount("#app");
