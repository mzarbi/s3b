import setTooltip from "@/assets/js/tooltip.js";
import VsudProgress from "@/views/ccmp/simple/VsudProgress.vue";
import img1 from "@/assets/img/small-logos/logo-xd.svg";
import img2 from "@/assets/img/team-1.jpg";
import img3 from "@/assets/img/team-2.jpg";
import img4 from "@/assets/img/team-3.jpg";
import img5 from "@/assets/img/team-4.jpg";
import img6 from "@/assets/img/small-logos/logo-atlassian.svg";
import img7 from "@/assets/img/team-2.jpg";
import img8 from "@/assets/img/team-4.jpg";
import img9 from "@/assets/img/small-logos/logo-slack.svg";
import img10 from "@/assets/img/team-3.jpg";
import img11 from "@/assets/img/team-1.jpg";
import img12 from "@/assets/img/small-logos/logo-spotify.svg";
import img13 from "@/assets/img/team-4.jpg";
import img14 from "@/assets/img/team-3.jpg";
import img15 from "@/assets/img/team-4.jpg";
import img16 from "@/assets/img/team-1.jpg";
import img17 from "@/assets/img/small-logos/logo-jira.svg";
import img18 from "@/assets/img/team-4.jpg";
import img19 from "@/assets/img/small-logos/logo-invision.svg";
import img20 from "@/assets/img/team-1.jpg";
import img21 from "@/assets/img/team-4.jpg";
import axios from 'axios';
import handlePagination from "./handlePagination";
import { ref, onMounted } from "vue";
import { useStore } from 'vuex'
export default {
  data() {
    return {
      img1,
      img2,
      img3,
      img4,
      img5,
      img6,
      img7,
      img8,
      img9,
      img10,
      img11,
      img12,
      img13,
      img14,
      img15,
      img16,
      img17,
      img18,
      img19,
      img20,
      img21,
    };
  },
  setup() {
    const store = useStore();
    const users = ref([]);
    var url = store.state.backendUrl;
    onMounted(async () => {
      const path = url + 'archives';
      const res = await axios.get(path);
      users.value = res.data;
    });

    const handlePaginationValue = handlePagination();
    return { ...handlePaginationValue,users };
  },
  methods: {
    restore_flow(event){
        if (event) {
          this.$swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
              if (result.isConfirmed) {
                  const uuid = event.target.value;
                  axios.get(this.$store.state.backendUrl + 'archives').then((res) => {
                      console.log(res.data);
                      const business_unit = res.data.find(x => x.uuid === uuid).business_unit;
                      const path = this.$store.state.backendUrl + 'task/restore/' + business_unit + '/' + uuid;
                      axios.get(path).then((res2) => {
                          console.log(res2);
                          this.$router.go(this.$router.currentRoute);
                      }).catch((error) => {
                          console.error(error);
                      });
                  }).catch((error) => {
                      console.error(error);
                  });

              }
            });

        }
    },
  },
  created() {
  },
  components: {
    VsudProgress,
  },
  mounted() {
    setTooltip();
  },
};