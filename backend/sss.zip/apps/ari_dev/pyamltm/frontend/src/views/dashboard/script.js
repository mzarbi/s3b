
import MiniStatisticsCard from "@/views/ccmp/composite/Cards/MiniStatisticsCard.vue";
import GradientLineChart from "@/views/ccmp/composite/Charts/GradientLineChart.vue";
import ProjectsCard from "@/views/components/projects_card/ProjectsCard.vue";
import InfoDialog from "@/views/ccmp/dialogs/InfoDialog";
import {
  faHandPointer,
  faUsers,
  faCreditCard,
  faScrewdriverWrench,
} from "@fortawesome/free-solid-svg-icons";
import axios from 'axios';
import {ref} from 'vue'

export default {
  name: "dashboard-default",
  data() {
    return {
      kpis: [],
      childDataLoaded: false,
      chart_values: {},
      admin_msg:{},
      iconBackground: "bg-gradient-success",
      faCreditCard,
      faScrewdriverWrench,
      faUsers,
      faHandPointer
    };
  },
  setup() {
    const dialogState = ref(false);
    return {
        dialogState
    };
  },
  methods: {
    getAdminMsg() {
      const path = this.$store.state.backendUrl + 'admin-msg';
      axios.get(path)
        .then((res) => {
          this.admin_msg = res.data;
        })
        .catch((error) => {
          console.error(error);
        });
    },
    getKpis() {
      const path = this.$store.state.backendUrl + 'fast-kpis';
      axios.get(path)
        .then((res) => {
          this.kpis = res.data;
          console.log(this.kpis);
        })
        .catch((error) => {
          // eslint-disable-next-line
          console.error(error);
        });
    },

    getDashboardChartValues() {
      const path = this.$store.state.backendUrl + 'dashboard-chart';
      axios.get(path)
        .then((res) => {
          this.childDataLoaded = true;
          this.chart_values = res.data;
          console.log(res.data);
        })
        .catch((error) => {
          console.error(error);
        });
    },
  },

  mounted(){
    this.getDashboardChartValues();
  },
  created() {
    this.getAdminMsg();
    this.getKpis();

  },
  components: {
    MiniStatisticsCard,
    GradientLineChart,
    ProjectsCard,
    InfoDialog
  },
};
