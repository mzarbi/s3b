
import ProjectsCard from "@/views/components/projects_card_detailed/ProjectsCardDetailed.vue";

export default {
  name: "tables",

  components: {
    ProjectsCard,
  },
};
