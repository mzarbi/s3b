import { ref, computed } from "vue";

export default function handlePagination() {
  let page = ref(1);

  const data = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24
  ].map((item) => {
    return { index: item, value: `this_${item}` };
  });

  const perPage = 10;

  const paginatedData = computed(() =>
    data.slice((page.value - 1) * perPage, page.value * perPage)
  );


  const buildPaginatedData = (dat) => {
    return dat.slice((page.value - 1) * perPage, page.value * perPage);
  };

  const updateNextPage = (dat) => {
    if (page.value !== Math.ceil(dat.length / perPage)) {
      page.value += 1;
    }
  };
  const nextPage = () => {
    if (page.value !== Math.ceil(data.length / perPage)) {
      page.value += 1;
    }
  };

  const backPage = () => {
    if (page.value !== 1) {
      page.value -= 1;
    }
  };

  const goToPage = (numPage) => {
    page.value = numPage;
  };

  return { data, paginatedData, perPage, page, nextPage,updateNextPage, backPage, goToPage,buildPaginatedData };
}
