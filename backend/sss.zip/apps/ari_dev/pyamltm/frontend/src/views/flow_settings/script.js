import VsudSwitch from "@/views/ccmp/simple/VsudSwitch.vue";
import VsudInput from "@/views/ccmp/simple/VsudInput.vue";
import sophie from "@/assets/img/kal-visuals-square.jpg";
import marie from "@/assets/img/marie.jpg";
import ivana from "@/assets/img/ivana-square.jpg";
import peterson from "@/assets/img/team-4.jpg";
import nick from "@/assets/img/team-3.jpg";
import img1 from "@/assets/img/home-decor-1.jpg";
import img2 from "@/assets/img/home-decor-2.jpg";
import img3 from "@/assets/img/home-decor-3.jpg";
import team1 from "@/assets/img/team-1.jpg";
import team2 from "@/assets/img/team-2.jpg";
import team3 from "@/assets/img/team-3.jpg";
import team4 from "@/assets/img/team-4.jpg";
import { faFacebook, faTwitter, faInstagram } from "@fortawesome/free-brands-svg-icons";
import axios from "axios";
import FormData from 'form-data';
import Tabs from "@/views/ccmp/composite/Tabs/Tabs.vue";
import Tab from "@/views/ccmp/composite/Tabs/Tab.vue";

export default {
    name: "flow-settings",
    components: {
        VsudSwitch,
        VsudInput,
        Tab,
        Tabs
    },
    props: ["settings_button_caption", "flow_specs" ],
    data() {
        return {
            message_displayed: false,
            uuid: this.$route.params.uuid,
            clusters:{},
            specs: {},
            flow_name: "FLOW_" + Math.random().toString().substr(2, 8),
            flow_description: "This is a complete AML FLow",
            flow_gcars_report: "",
            gcars_report_list: [],
            flow_sensitivity_report: "",
            sensitivity_report_list: [],
            flow_kyc_reliance_worldwide_report: "",
            kyc_reliance_worldwide_report_list: [],
            flow_country_risk_report: "",
            country_risk_report_list: [],
            flow_actimize_version: 8,
            actimize_version_list: [3, 8],
            flow_models: ["EFT", "FTF", "TSD"],
            models_list: [],
            flow_business_unit: "",
            business_unit_list: [],
            flow_local_currency_rate: 1,
            flow_tracking: true,
            flow_lookback_period: 2,
            flow_bucket_mapping_mode: "SIMPLE",
            bucket_mapping_mode_list: ["ADVANCED", "SIMPLE"],
            flow_data_start_date: "2020-10-01",
            flow_data_end_date: "2021-12-31",
            flow_train_start_date: "2020-10-01",
            flow_train_end_date: "2021-09-30",
            flow_test_start_date: "2021-10-01",
            flow_test_end_date: "2021-12-31",
            low_gmm_risk_level :1,
            low_cls_risk_level:1,
            medium_gmm_risk_level :1,
            medium_cls_risk_level:1,
            high_gmm_risk_level :1,
            high_cls_risk_level:1,

            flow_excessive_single_transactions_low_risk: 95,
            flow_excessive_single_transactions_medium_risk: 85,
            flow_excessive_single_transactions_high_risk: 75,
            flow_flow_through_of_funds__credits___debits__low_risk: 95,
            flow_flow_through_of_funds__credits___debits__medium_risk: 85,
            flow_flow_through_of_funds__credits___debits__high_risk: 75,
            flow_transfer_to_from_high_risk_countries__level_3__low_risk: 95,
            flow_transfer_to_from_high_risk_countries__level_3__medium_risk: 85,
            flow_transfer_to_from_high_risk_countries__level_3__high_risk: 75,
            flow_transfer_to_from_very_high_risk_countries__level_4__low_risk: 95,
            flow_transfer_to_from_very_high_risk_countries__level_4__medium_risk: 85,
            flow_transfer_to_from_very_high_risk_countries__level_4__high_risk: 70,

            flow_excessive_single_transactions_escalation_significantly_below_average: 60,
            flow_excessive_single_transactions_account_hits_significantly_above_average: 25,
            flow_excessive_single_transactions_hits_from_escalations_significantly_above_average:25,

            flow_flow_through_of_funds__credits___debits__escalation_significantly_below_average: 60,
            flow_flow_through_of_funds__credits___debits__account_hits_significantly_above_average: 50,
            flow_flow_through_of_funds__credits___debits__hits_from_escalations_significantly_above_average: 50,

            flow_transfer_to_from_high_risk_countries__level_3__escalation_significantly_below_average: 60,
            flow_transfer_to_from_high_risk_countries__level_3__account_hits_significantly_above_average: 50,
            flow_transfer_to_from_high_risk_countries__level_3__hits_from_escalations_significantly_above_average: 50,


            flow_transfer_to_from_very_high_risk_countries__level_4__escalation_significantly_below_average: 30,
            flow_transfer_to_from_very_high_risk_countries__level_4__account_hits_significantly_above_average: 130,
            flow_transfer_to_from_very_high_risk_countries__level_4__hits_from_escalations_significantly_above_average: 130,

            toggle_use_these_values_state: false,
            toggle_flow_parameters_state: true,
            toggle_advanced_parameters_state: false,
            toggle_enable_advanced_parameters_state: true,

            flow_startup_download_files: true,
            toggle_enable_startup_state: true,
            toggle_startup_state: false,
            flow_step0_experiment_key: "RAW",
            flow_step0_pipeline_steps_parameters_serialization_parameters: "KEY",
            flow_step0_pipeline_steps_data_serialization_alerts_serialisation: true,
            flow_step0_pipeline_steps_data_serialization_transactions_serialisation: true,
            flow_step0_pipeline_steps_data_serialization_amlit_alerts_serialisation: "",
            flow_step0_pipeline_steps_data_serialization_lookback_sums: true,
            toggle_enable_step0_state: true,
            toggle_step0_state: false,
            flow_step1_experiment_key: "run0_simul",
            flow_step1_pipeline_steps_clustering_features_transactions: "RAW",
            flow_step1_pipeline_steps_clustering_features_parameters: "RAW",
            flow_step1_pipeline_steps_clustering_features_lookback_sums: "RAW",
            toggle_enable_step1_state: true,
            toggle_step1_state: false,
            flow_step2_experiment_key: "experiment_key",
            flow_step2_pipeline_steps_clustering_transactions: "RAW",
            flow_step2_pipeline_steps_clustering_features: "run0_simul",
            flow_step2_pipeline_steps_clustering_clusters: "KEY",
            flow_step2_pipeline_steps_clustering_lookback_sums: "RAW",
            flow_step2_pipeline_steps_thresholds_transactions: "KEY",
            flow_step2_pipeline_steps_thresholds_parameters: "RAW",
            flow_step2_pipeline_steps_thresholds_l2_recall_train: 100.0,
            flow_step2_pipeline_steps_thresholds_l2_recall_test: 100.0,
            flow_step2_pipeline_steps_thresholds_lookback_sums: "KEY",
            flow_step2_pipeline_steps_thresholds_features: "run0_simul",
            flow_step2_pipeline_steps_alerting_transactions: "KEY",
            flow_step2_pipeline_steps_alerting_prod_alerts: ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP"],
            flow_step2_pipeline_steps_alerting_prod_alerts_key: "truth",
            flow_step2_pipeline_steps_alerting_parameters: "RAW",
            flow_step2_pipeline_steps_alerting_lookback_sums: "KEY",
            flow_step2_pipeline_steps_alerting_thresholds: "KEY",
            flow_step2_pipeline_steps_alerting_analysis_dates: "TRAIN",
            flow_step2_pipeline_steps_kpis_transactions: "KEY",
            flow_step2_pipeline_steps_kpis_alerts: "KEY",
            flow_step2_pipeline_steps_kpis_baseline: "truth",
            flow_step2_pipeline_steps_kpis_parameters: "RAW",
            flow_step2_pipeline_steps_kpis_analysis_dates: "TRAIN",
            toggle_enable_step2_state: true,
            toggle_step2_state: false,
            toggle_enable_manuallock_state: true,
            toggle_manuallock_state: false,
            flow_step3_experiment_key: "run0_best_cluster",
            flow_step3_pipeline_steps_clustering_transactions: "RAW",
            flow_step3_pipeline_steps_clustering_features: "run0_simul",
            flow_step3_pipeline_steps_clustering_clusters: "KEY",
            flow_step3_pipeline_steps_clustering_lookback_sums: "RAW",
            flow_step3_pipeline_steps_thresholds_transactions: "KEY",
            flow_step3_pipeline_steps_thresholds_parameters: "RAW",
            flow_step3_pipeline_steps_thresholds_l2_recall_train: 100.0,
            flow_step3_pipeline_steps_thresholds_l2_recall_test: 100.0,
            flow_step3_pipeline_steps_thresholds_lookback_sums: "KEY",
            flow_step3_pipeline_steps_thresholds_features: "run0_simul",
            flow_step3_pipeline_steps_alerting_transactions: "KEY",
            flow_step3_pipeline_steps_alerting_prod_alerts: ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP"],
            flow_step3_pipeline_steps_alerting_prod_alerts_key: "truth",
            flow_step3_pipeline_steps_alerting_parameters: "RAW",
            flow_step3_pipeline_steps_alerting_lookback_sums: "KEY",
            flow_step3_pipeline_steps_alerting_thresholds: "KEY",
            flow_step3_pipeline_steps_alerting_analysis_dates: "TEST",
            flow_step3_pipeline_steps_kpis_transactions: "KEY",
            flow_step3_pipeline_steps_kpis_alerts: "KEY",
            flow_step3_pipeline_steps_kpis_baseline: "truth",
            flow_step3_pipeline_steps_kpis_parameters: "RAW",
            flow_step3_pipeline_steps_kpis_analysis_dates: "TEST",
            flow_step3_pipeline_steps_files_export_features: "run0_simul",
            flow_step3_pipeline_steps_files_export_thresholds: "KEY",
            flow_step3_pipeline_steps_files_export_parameters: "RAW",
            flow_step3_pipeline_steps_files_export_transactions: "KEY",
            flow_step3_pipeline_steps_files_export_clusters: "KEY",
            flow_step3_pipeline_steps_files_export_alerts: "KEY",
            toggle_enable_step3_state: true,
            toggle_step3_state: false,
            flow_step4_experiment_key: "run0_acti",
            flow_step4_cluster_key: "run0_simul",
            flow_step4_pipeline_steps_data_serialization_alerts_serialisation: false,
            flow_step4_pipeline_steps_data_serialization_transactions_serialisation: false,
            flow_step4_pipeline_steps_data_serialization_amlit_alerts_serialisation: "run0",
            flow_step4_pipeline_steps_data_serialization_lookback_sums: false,
            flow_step4_pipeline_steps_alerting_transactions: "run0_best_cluster",
            flow_step4_pipeline_steps_alerting_prod_alerts: ["ADR", "CTF", "EPC", "KHI", "KLO", "LTH", "NBI", "SBP", "STP", "THV"],
            flow_step4_pipeline_steps_alerting_prod_alerts_key: "run0_AMLIT",
            flow_step4_pipeline_steps_alerting_parameters: "RAW",
            flow_step4_pipeline_steps_alerting_lookback_sums: "run0_best_cluster",
            flow_step4_pipeline_steps_alerting_thresholds: "run0_best_cluster",
            flow_step4_pipeline_steps_alerting_analysis_dates: "TEST",
            flow_step4_pipeline_steps_kpis_transactions: "run0_best_cluster",
            flow_step4_pipeline_steps_kpis_alerts: "KEY",
            flow_step4_pipeline_steps_kpis_baseline: "run0_AMLIT",
            flow_step4_pipeline_steps_kpis_parameters: "RAW",
            flow_step4_pipeline_steps_kpis_analysis_dates: "TEST",
            toggle_enable_step4_state: true,
            toggle_step4_state: false,
            flow_step5_experiment_key: "run0_acti",
            flow_step5_pipeline_steps_files_export_features: "run0_simul",
            flow_step5_pipeline_steps_files_export_thresholds: "run0_best_cluster",
            flow_step5_pipeline_steps_files_export_parameters: "RAW",
            flow_step5_pipeline_steps_files_export_transactions: "run0_best_cluster",
            flow_step5_pipeline_steps_files_export_clusters: "run0_best_cluster",
            flow_step5_pipeline_steps_files_export_alerts: "run0_AMLIT",
            toggle_enable_step5_state: true,
            toggle_step5_state: false,
            flow_rollback_delete_input_cache: false,
            flow_rollback_delete_kyc_cache: false,
            flow_rollback_delete_output_cache: false,
            toggle_enable_rollback_state: false,
            toggle_rollback_state: false,
            flow_step0_skip: true,
            flow_step1_skip: true,
            flow_step2_skip: true,
            flow_step3_skip: true,
            flow_step4_skip: true,
            flow_step5_skip: true,
            thresholdParametersFile:null,
            bucketsFile:null,
            showMenu: false,
            sophie,
            marie,
            ivana,
            peterson,
            nick,
            img1,
            team1,
            team2,
            team3,
            team4,
            img2,
            img3,
            faFacebook,
            faTwitter,
            faInstagram,
        };
    },
    methods: {
        init_model(){

        },
        uploadThresholdParametersFile() {
            this.thresholdParametersFile = this.$refs.thresholdParametersFile.files[0];
        },
        uploadBucketFile() {
            this.bucketsFile = this.$refs.bucketFile.files[0];
        },

        toggle_use_these_values(){
            this.toggle_use_these_values_state = !this.toggle_use_these_values_state;
        },
        toggle_enable_advanced_parameters() {
            if (this.toggle_enable_advanced_parameters_state) {
                this.$swal.fire({
                    title: "Be careful, These configurations are reserved to advanced users.",
                    showDenyButton: false,
                    showCancelButton: false,
                    confirmButtonText: "Proceed",
                });
            }
            this.toggle_enable_advanced_parameters_state = !this.toggle_enable_advanced_parameters_state;
        },
        toggle_flow_parameters() {
            this.toggle_flow_parameters_state = !this.toggle_flow_parameters_state;
        },
        toggle_advanced_parameters() {
            this.toggle_advanced_parameters_state = !this.toggle_advanced_parameters_state;
        },
        toggle_startup() {
            this.toggle_startup_state = !this.toggle_startup_state;
        },
        toggle_enable_startup() {
            if (this.toggle_enable_startup_state) {
                this.alert_message();
            }
            this.toggle_enable_startup_state = !this.toggle_enable_startup_state;
        },

        toggle_step0() {
            this.toggle_step0_state = !this.toggle_step0_state;
        },
        toggle_enable_step0() {
            if (this.toggle_enable_step0_state) {
                this.alert_message();
            }
            this.toggle_enable_step0_state = !this.toggle_enable_step0_state;
        },

        toggle_step1() {
            this.toggle_step1_state = !this.toggle_step1_state;
        },
        toggle_enable_step1() {
            if (this.toggle_enable_step1_state) {
                this.alert_message();
            }
            this.toggle_enable_step1_state = !this.toggle_enable_step1_state;
        },

        toggle_step2() {
            this.toggle_step2_state = !this.toggle_step2_state;
        },
        toggle_enable_step2() {
            if (this.toggle_enable_step2_state) {
                this.alert_message();
            }
            this.toggle_enable_step2_state = !this.toggle_enable_step2_state;
        },

        toggle_manuallock() {
            this.toggle_manuallock_state = !this.toggle_manuallock_state;
        },
        toggle_enable_manuallock() {
            if (this.toggle_enable_manuallock_state) {
                this.alert_message();
            }
            this.toggle_enable_manuallock_state = !this.toggle_enable_manuallock_state;
        },

        toggle_step3() {
            this.toggle_step3_state = !this.toggle_step3_state;
        },
        toggle_enable_step3() {
            if (this.toggle_enable_step3_state) {
                this.alert_message();
            }
            this.toggle_enable_step3_state = !this.toggle_enable_step3_state;
        },

        toggle_step4() {
            this.toggle_step4_state = !this.toggle_step4_state;
        },
        toggle_enable_step4() {
            if (this.toggle_enable_step4_state) {
                this.alert_message();
            }
            this.toggle_enable_step4_state = !this.toggle_enable_step4_state;
        },

        toggle_step5() {
            this.toggle_step5_state = !this.toggle_step5_state;
        },
        toggle_enable_step5() {
            if (this.toggle_enable_step5_state) {
                this.alert_message();
            }
            this.toggle_enable_step5_state = !this.toggle_enable_step5_state;
        },
        toggle_flow_tracking(){
            this.flow_tracking = !this.flow_tracking;
        },
        toggle_flow_startup_download_files(){
            this.flow_startup_download_files = !this.flow_startup_download_files;
        },
        toggle_flow_step0_skip(){
            this.flow_step0_skip = !this.flow_step0_skip;
        },
        toggle_flow_step0_pipeline_steps_data_serialization_alerts_serialisation(){
            this.flow_step0_pipeline_steps_data_serialization_alerts_serialisation = !this.flow_step0_pipeline_steps_data_serialization_alerts_serialisation;
        },
        toggle_flow_step0_pipeline_steps_data_serialization_transactions_serialisation(){
            this.flow_step0_pipeline_steps_data_serialization_transactions_serialisation = !this.flow_step0_pipeline_steps_data_serialization_transactions_serialisation;
        },
        toggle_flow_step0_pipeline_steps_data_serialization_lookback_sums(){
            this.flow_step0_pipeline_steps_data_serialization_lookback_sums = !this.flow_step0_pipeline_steps_data_serialization_lookback_sums;
        },
        toggle_flow_step1_skip(){
            this.flow_step1_skip = !this.flow_step1_skip;
        },
        toggle_flow_step2_skip(){
            this.flow_step2_skip = !this.flow_step2_skip;
        },
        toggle_flow_step3_skip(){
            this.flow_step3_skip = !this.flow_step3_skip;
        },
        toggle_flow_step4_skip(){
            this.flow_step4_skip = !this.flow_step4_skip;
        },
        toggle_flow_step4_pipeline_steps_data_serialization_alerts_serialisation(){
            this.flow_step4_pipeline_steps_data_serialization_alerts_serialisation = !this.flow_step4_pipeline_steps_data_serialization_alerts_serialisation;
        },
        toggle_flow_step4_pipeline_steps_data_serialization_transactions_serialisation(){
            this.flow_step4_pipeline_steps_data_serialization_transactions_serialisation = !this.flow_step4_pipeline_steps_data_serialization_transactions_serialisation;
        },
        toggle_flow_step4_pipeline_steps_data_serialization_lookback_sums(){
            this.flow_step4_pipeline_steps_data_serialization_lookback_sums = !this.flow_step4_pipeline_steps_data_serialization_lookback_sums;
        },
        toggle_flow_step5_skip(){
            this.flow_step5_skip = !this.flow_step5_skip;
        },
        toggle_flow_rollback_delete_input_cache(){
            this.flow_rollback_delete_input_cache = !this.flow_rollback_delete_input_cache;
        },
        toggle_flow_rollback_delete_kyc_cache(){
            this.flow_rollback_delete_kyc_cache = !this.flow_rollback_delete_kyc_cache;
        },
        toggle_flow_rollback_delete_output_cache(){
            this.flow_rollback_delete_output_cache = !this.flow_rollback_delete_output_cache;
        },
        toggle_rollback() {
            this.toggle_rollback_state = !this.toggle_rollback_state;
        },
        toggle_enable_rollback() {
            if (this.toggle_enable_rollback_state) {
                this.alert_message();
            }
            this.toggle_enable_rollback_state = !this.toggle_enable_rollback_state;
        },
        alert_message(){
            if(!this.message_displayed){
                this.message_displayed = true;
                this.$swal.fire({
                    title: "Be careful, These configurations are reserved to advanced users.",
                    showDenyButton: false,
                    showCancelButton: false,
                    confirmButtonText: "Proceed",
                });
            }
        },

        update_model(){
            try {
                this.low_gmm_risk_level = Number(this.specs.flow_cfg.GMM_COMPONENTS_RISK_LEVEL["0-LOW"])
                this.medium_gmm_risk_level = Number(this.specs.flow_cfg.GMM_COMPONENTS_RISK_LEVEL["1-MEDIUM"])
                this.high_gmm_risk_level = Number(this.specs.flow_cfg.GMM_COMPONENTS_RISK_LEVEL["2-HIGH"])

                this.low_cls_risk_level = Number(this.specs.flow_cfg.CLUSTERS_NUMBER_RISK_LEVEL["0-LOW"])
                this.medium_cls_risk_level = Number(this.specs.flow_cfg.CLUSTERS_NUMBER_RISK_LEVEL["1-MEDIUM"])
                this.high_cls_risk_level = Number(this.specs.flow_cfg.CLUSTERS_NUMBER_RISK_LEVEL["2-HIGH"])
            }
            catch (e) {
                console.log(e);
            }


            this.flow_name = this.specs.flow_cfg.NAME;

            this.flow_description= this.specs.flow_cfg.DESCRIPTION;
            this.flow_actimize_version= Number(this.specs.flow_cfg.MODEL_VERSION.substring(this.specs.flow_cfg.MODEL_VERSION.length - 1));
            this.flow_models= this.specs.flow_cfg.LIST_MODEL;
            this.flow_business_unit= this.specs.flow_cfg.BU;
            this.flow_local_currency_rate= this.specs.flow_cfg.LOCAL_CURRENCY_RATE;
            this.flow_tracking= this.specs.flow_cfg.TRACKING;
            this.flow_lookback_period= this.specs.flow_cfg.LOOKBACK_PERIOD;
            this.flow_bucket_mapping_mode= this.specs.flow_cfg.BUCKET_MAPPING_MODE;
            this.flow_data_start_date= this.specs.flow_cfg.ANALYSIS_DATES.DATA.FROM;
            this.flow_data_end_date= this.specs.flow_cfg.ANALYSIS_DATES.DATA.TO;
            this.flow_train_start_date= this.specs.flow_cfg.ANALYSIS_DATES.TRAIN.FROM;
            this.flow_train_end_date= this.specs.flow_cfg.ANALYSIS_DATES.TRAIN.TO;
            this.flow_test_start_date= this.specs.flow_cfg.ANALYSIS_DATES.TEST.FROM;
            this.flow_test_end_date= this.specs.flow_cfg.ANALYSIS_DATES.TEST.TO;

            this.flow_excessive_single_transactions_low_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Excessive Single Transactions"][0];
            this.flow_excessive_single_transactions_medium_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Excessive Single Transactions"][1];
            this.flow_excessive_single_transactions_high_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Excessive Single Transactions"][2];
            this.flow_flow_through_of_funds__credits___debits__low_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Flow Through of Funds (Credits / Debits)"][0];
            this.flow_flow_through_of_funds__credits___debits__medium_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Flow Through of Funds (Credits / Debits)"][1];
            this.flow_flow_through_of_funds__credits___debits__high_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Flow Through of Funds (Credits / Debits)"][2];
            this.flow_transfer_to_from_high_risk_countries__level_3__low_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Transfer to/from High-Risk Countries (Level 3)"][0];
            this.flow_transfer_to_from_high_risk_countries__level_3__medium_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Transfer to/from High-Risk Countries (Level 3)"][1];
            this.flow_transfer_to_from_high_risk_countries__level_3__high_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Transfer to/from High-Risk Countries (Level 3)"][2];
            this.flow_transfer_to_from_very_high_risk_countries__level_4__low_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Transfer to/from Very High-Risk Countries (Level 4)"][0];
            this.flow_transfer_to_from_very_high_risk_countries__level_4__medium_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Transfer to/from Very High-Risk Countries (Level 4)"][1];
            this.flow_transfer_to_from_very_high_risk_countries__level_4__high_risk= this.specs.flow_cfg.STANDARD_PERCENTILE["Transfer to/from Very High-Risk Countries (Level 4)"][2];

            this.flow_excessive_single_transactions_escalation_significantly_below_average= this.specs.flow_cfg.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Excessive Single Transactions"];
            this.flow_excessive_single_transactions_account_hits_significantly_above_average= this.specs.flow_cfg.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Excessive Single Transactions"];
            this.flow_excessive_single_transactions_hits_from_escalations_significantly_above_average= this.specs.flow_cfg.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE["Excessive Single Transactions"];

            this.flow_flow_through_of_funds__credits___debits__escalation_significantly_below_average= this.specs.flow_cfg.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Flow Through of Funds (Credits / Debits)"];
            this.flow_flow_through_of_funds__credits___debits__account_hits_significantly_above_average= this.specs.flow_cfg.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Flow Through of Funds (Credits / Debits)"];
            this.flow_flow_through_of_funds__credits___debits__hits_from_escalations_significantly_above_average= this.specs.flow_cfg.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE["Flow Through of Funds (Credits / Debits)"];


            this.flow_transfer_to_from_high_risk_countries__level_3__escalation_significantly_below_average= this.specs.flow_cfg.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Transfer to/from High-Risk Countries (Level 3)"];
            this.flow_transfer_to_from_high_risk_countries__level_3__account_hits_significantly_above_average= this.specs.flow_cfg.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Transfer to/from High-Risk Countries (Level 3)"];
            this.flow_transfer_to_from_high_risk_countries__level_3__hits_from_escalations_significantly_above_average= this.specs.flow_cfg.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE["Transfer to/from High-Risk Countries (Level 3)"];



            this.flow_transfer_to_from_very_high_risk_countries__level_4__escalation_significantly_below_average= this.specs.flow_cfg.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Transfer to/from Very High-Risk Countries (Level 4)"];
            this.flow_transfer_to_from_very_high_risk_countries__level_4__account_hits_significantly_above_average= this.specs.flow_cfg.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Transfer to/from Very High-Risk Countries (Level 4)"];
            this.flow_transfer_to_from_very_high_risk_countries__level_4__hits_from_escalations_significantly_above_average= this.specs.flow_cfg.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE["Transfer to/from Very High-Risk Countries (Level 4)"];


        },
        export_model() {
            var tsk = {
                NAME: this.flow_name,
                DESCRIPTION: this.flow_description,
                MODEL_VERSION: "SAM" + Number(this.flow_actimize_version),
                LIST_MODEL: this.flow_models,
                KYC: {
                    GCARS_REPORT: this.flow_gcars_report,
                    SENSITIVITY_REPORT: this.flow_sensitivity_report,
                    KYC_RELIANCE_WORLDWIDE_REPORT: this.flow_kyc_reliance_worldwide_report,
                    COUNTRY_RISK_REPORT: this.flow_country_risk_report,
                },
                BU: this.flow_business_unit,
                LOCAL_CURRENCY_RATE: parseFloat("" + this.flow_local_currency_rate),
                TRACKING: this.flow_tracking,
                LOOKBACK_PERIOD: Number(this.flow_lookback_period),
                BUCKET_MAPPING_MODE: this.flow_bucket_mapping_mode,
                ANALYSIS_DATES: {
                    DATA: {
                        FROM: this.flow_data_start_date,
                        TO: this.flow_data_end_date,
                    },
                    TRAIN: {
                        FROM: this.flow_train_start_date,
                        TO: this.flow_train_end_date,
                    },
                    TEST: {
                        FROM: this.flow_test_start_date,
                        TO: this.flow_test_end_date,
                    },
                },
                PERCENT_ESCALATION_SIGNIFICANTLY_BELOW: {
                    "Excessive Single Transactions": parseFloat("" + this.flow_excessive_single_transactions_escalation_significantly_below_average),
                    "Flow Through of Funds (Credits / Debits)": parseFloat("" + this.flow_flow_through_of_funds__credits___debits__escalation_significantly_below_average),
                    "Transfer to/from High-Risk Countries (Level 3)": parseFloat("" + this.flow_transfer_to_from_high_risk_countries__level_3__escalation_significantly_below_average),
                    "Transfer to/from Very High-Risk Countries (Level 4)": parseFloat("" + this.flow_transfer_to_from_very_high_risk_countries__level_4__escalation_significantly_below_average),
                },
                HITS_ACCOUNT_SIGNIFICANTLY_ABOVE: {
                    "Excessive Single Transactions": parseFloat("" + this.flow_excessive_single_transactions_account_hits_significantly_above_average),
                    "Flow Through of Funds (Credits / Debits)": parseFloat("" + this.flow_flow_through_of_funds__credits___debits__account_hits_significantly_above_average),
                    "Transfer to/from High-Risk Countries (Level 3)": parseFloat("" + this.flow_transfer_to_from_high_risk_countries__level_3__account_hits_significantly_above_average),
                    "Transfer to/from Very High-Risk Countries (Level 4)": parseFloat("" + this.flow_transfer_to_from_very_high_risk_countries__level_4__account_hits_significantly_above_average),
                },
                HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE: {
                    "Excessive Single Transactions": parseFloat("" + this.flow_excessive_single_transactions_hits_from_escalations_significantly_above_average),
                    "Flow Through of Funds (Credits / Debits)": parseFloat("" + this.flow_flow_through_of_funds__credits___debits__hits_from_escalations_significantly_above_average),
                    "Transfer to/from High-Risk Countries (Level 3)": parseFloat("" + this.flow_transfer_to_from_high_risk_countries__level_3__hits_from_escalations_significantly_above_average),
                    "Transfer to/from Very High-Risk Countries (Level 4)": parseFloat("" + this.flow_transfer_to_from_very_high_risk_countries__level_4__hits_from_escalations_significantly_above_average),
                },
                STANDARD_PERCENTILE: {
                    "Excessive Single Transactions": [parseFloat("" + this.flow_excessive_single_transactions_low_risk), parseFloat("" + this.flow_excessive_single_transactions_medium_risk), parseFloat("" + this.flow_excessive_single_transactions_high_risk)],
                    "Flow Through of Funds (Credits / Debits)": [
                        parseFloat("" + this.flow_flow_through_of_funds__credits___debits__low_risk),
                        parseFloat("" + this.flow_flow_through_of_funds__credits___debits__medium_risk),
                        parseFloat("" + this.flow_flow_through_of_funds__credits___debits__high_risk),
                    ],
                    "Transfer to/from High-Risk Countries (Level 3)": [
                        parseFloat("" + this.flow_transfer_to_from_high_risk_countries__level_3__low_risk),
                        parseFloat("" + this.flow_transfer_to_from_high_risk_countries__level_3__medium_risk),
                        parseFloat("" + this.flow_transfer_to_from_high_risk_countries__level_3__high_risk),
                    ],
                    "Transfer to/from Very High-Risk Countries (Level 4)": [
                        parseFloat("" + this.flow_transfer_to_from_very_high_risk_countries__level_4__low_risk),
                        parseFloat("" + this.flow_transfer_to_from_very_high_risk_countries__level_4__medium_risk),
                        parseFloat("" + this.flow_transfer_to_from_very_high_risk_countries__level_4__high_risk),
                    ],
                },

            };
            if (this.toggle_use_these_values_state){

                tsk.GMM_COMPONENTS_RISK_LEVEL = {
                    "0-LOW": Number(this.low_gmm_risk_level),
                    "1-MEDIUM": Number(this.medium_gmm_risk_level),
                    "2-HIGH": Number(this.high_gmm_risk_level)
                };
                tsk.CLUSTERS_NUMBER_RISK_LEVEL = {
                    "0-LOW": Number(this.low_cls_risk_level),
                    "1-MEDIUM": Number(this.medium_cls_risk_level),
                    "2-HIGH": Number(this.high_cls_risk_level)
                }
            }
            tsk = { flow: tsk };
            tsk.startup = {};
            tsk.startup.flow_startup_download_files = this.flow_startup_download_files;
            tsk.step0 = {};
            tsk.step0.flow_step0_skip = this.flow_step0_skip;
            tsk.step0.flow_step0_experiment_key = this.flow_step0_experiment_key;
            tsk.step0.flow_step0_pipeline_steps_parameters_serialization_parameters = this.flow_step0_pipeline_steps_parameters_serialization_parameters;
            tsk.step0.flow_step0_pipeline_steps_data_serialization_alerts_serialisation = this.flow_step0_pipeline_steps_data_serialization_alerts_serialisation;
            tsk.step0.flow_step0_pipeline_steps_data_serialization_transactions_serialisation = this.flow_step0_pipeline_steps_data_serialization_transactions_serialisation;
            tsk.step0.flow_step0_pipeline_steps_data_serialization_amlit_alerts_serialisation = this.flow_step0_pipeline_steps_data_serialization_amlit_alerts_serialisation;
            tsk.step0.flow_step0_pipeline_steps_data_serialization_lookback_sums = this.flow_step0_pipeline_steps_data_serialization_lookback_sums;
            tsk.step1 = {};
            tsk.step1.flow_step1_skip = this.flow_step1_skip;
            tsk.step1.flow_step1_experiment_key = this.flow_step1_experiment_key;
            tsk.step1.flow_step1_pipeline_steps_clustering_features_transactions = this.flow_step1_pipeline_steps_clustering_features_transactions;
            tsk.step1.flow_step1_pipeline_steps_clustering_features_parameters = this.flow_step1_pipeline_steps_clustering_features_parameters;
            tsk.step1.flow_step1_pipeline_steps_clustering_features_lookback_sums = this.flow_step1_pipeline_steps_clustering_features_lookback_sums;
            tsk.step2 = {};
            tsk.step2.flow_step2_skip = this.flow_step2_skip;
            tsk.step2.flow_step2_experiment_key = this.flow_step2_experiment_key;
            tsk.step2.flow_step2_pipeline_steps_clustering_transactions = this.flow_step2_pipeline_steps_clustering_transactions;
            tsk.step2.flow_step2_pipeline_steps_clustering_features = this.flow_step2_pipeline_steps_clustering_features;
            tsk.step2.flow_step2_pipeline_steps_clustering_clusters = this.flow_step2_pipeline_steps_clustering_clusters;
            tsk.step2.flow_step2_pipeline_steps_clustering_lookback_sums = this.flow_step2_pipeline_steps_clustering_lookback_sums;
            tsk.step2.flow_step2_pipeline_steps_thresholds_transactions = this.flow_step2_pipeline_steps_thresholds_transactions;
            tsk.step2.flow_step2_pipeline_steps_thresholds_parameters = this.flow_step2_pipeline_steps_thresholds_parameters;
            tsk.step2.flow_step2_pipeline_steps_thresholds_l2_recall_train = this.flow_step2_pipeline_steps_thresholds_l2_recall_train;
            tsk.step2.flow_step2_pipeline_steps_thresholds_l2_recall_test = this.flow_step2_pipeline_steps_thresholds_l2_recall_test;
            tsk.step2.flow_step2_pipeline_steps_thresholds_lookback_sums = this.flow_step2_pipeline_steps_thresholds_lookback_sums;
            tsk.step2.flow_step2_pipeline_steps_thresholds_features = this.flow_step2_pipeline_steps_thresholds_features;
            tsk.step2.flow_step2_pipeline_steps_alerting_transactions = this.flow_step2_pipeline_steps_alerting_transactions;
            tsk.step2.flow_step2_pipeline_steps_alerting_prod_alerts = this.flow_step2_pipeline_steps_alerting_prod_alerts;
            tsk.step2.flow_step2_pipeline_steps_alerting_prod_alerts_key = this.flow_step2_pipeline_steps_alerting_prod_alerts_key;
            tsk.step2.flow_step2_pipeline_steps_alerting_parameters = this.flow_step2_pipeline_steps_alerting_parameters;
            tsk.step2.flow_step2_pipeline_steps_alerting_lookback_sums = this.flow_step2_pipeline_steps_alerting_lookback_sums;
            tsk.step2.flow_step2_pipeline_steps_alerting_thresholds = this.flow_step2_pipeline_steps_alerting_thresholds;
            tsk.step2.flow_step2_pipeline_steps_alerting_analysis_dates = this.flow_step2_pipeline_steps_alerting_analysis_dates;
            tsk.step2.flow_step2_pipeline_steps_kpis_transactions = this.flow_step2_pipeline_steps_kpis_transactions;
            tsk.step2.flow_step2_pipeline_steps_kpis_alerts = this.flow_step2_pipeline_steps_kpis_alerts;
            tsk.step2.flow_step2_pipeline_steps_kpis_baseline = this.flow_step2_pipeline_steps_kpis_baseline;
            tsk.step2.flow_step2_pipeline_steps_kpis_parameters = this.flow_step2_pipeline_steps_kpis_parameters;
            tsk.step2.flow_step2_pipeline_steps_kpis_analysis_dates = this.flow_step2_pipeline_steps_kpis_analysis_dates;
            tsk.step3 = {};
            tsk.step3.flow_step3_skip = this.flow_step3_skip;
            tsk.step3.flow_step3_experiment_key = this.flow_step3_experiment_key;
            tsk.step3.flow_step3_pipeline_steps_clustering_transactions = this.flow_step3_pipeline_steps_clustering_transactions;
            tsk.step3.flow_step3_pipeline_steps_clustering_features = this.flow_step3_pipeline_steps_clustering_features;
            tsk.step3.flow_step3_pipeline_steps_clustering_clusters = this.flow_step3_pipeline_steps_clustering_clusters;
            tsk.step3.flow_step3_pipeline_steps_clustering_lookback_sums = this.flow_step3_pipeline_steps_clustering_lookback_sums;
            tsk.step3.flow_step3_pipeline_steps_thresholds_transactions = this.flow_step3_pipeline_steps_thresholds_transactions;
            tsk.step3.flow_step3_pipeline_steps_thresholds_parameters = this.flow_step3_pipeline_steps_thresholds_parameters;
            tsk.step3.flow_step3_pipeline_steps_thresholds_l2_recall_train = this.flow_step3_pipeline_steps_thresholds_l2_recall_train;
            tsk.step3.flow_step3_pipeline_steps_thresholds_l2_recall_test = this.flow_step3_pipeline_steps_thresholds_l2_recall_test;
            tsk.step3.flow_step3_pipeline_steps_thresholds_lookback_sums = this.flow_step3_pipeline_steps_thresholds_lookback_sums;
            tsk.step3.flow_step3_pipeline_steps_thresholds_features = this.flow_step3_pipeline_steps_thresholds_features;
            tsk.step3.flow_step3_pipeline_steps_alerting_transactions = this.flow_step3_pipeline_steps_alerting_transactions;
            tsk.step3.flow_step3_pipeline_steps_alerting_prod_alerts = this.flow_step3_pipeline_steps_alerting_prod_alerts;
            tsk.step3.flow_step3_pipeline_steps_alerting_prod_alerts_key = this.flow_step3_pipeline_steps_alerting_prod_alerts_key;
            tsk.step3.flow_step3_pipeline_steps_alerting_parameters = this.flow_step3_pipeline_steps_alerting_parameters;
            tsk.step3.flow_step3_pipeline_steps_alerting_lookback_sums = this.flow_step3_pipeline_steps_alerting_lookback_sums;
            tsk.step3.flow_step3_pipeline_steps_alerting_thresholds = this.flow_step3_pipeline_steps_alerting_thresholds;
            tsk.step3.flow_step3_pipeline_steps_alerting_analysis_dates = this.flow_step3_pipeline_steps_alerting_analysis_dates;
            tsk.step3.flow_step3_pipeline_steps_kpis_transactions = this.flow_step3_pipeline_steps_kpis_transactions;
            tsk.step3.flow_step3_pipeline_steps_kpis_alerts = this.flow_step3_pipeline_steps_kpis_alerts;
            tsk.step3.flow_step3_pipeline_steps_kpis_baseline = this.flow_step3_pipeline_steps_kpis_baseline;
            tsk.step3.flow_step3_pipeline_steps_kpis_parameters = this.flow_step3_pipeline_steps_kpis_parameters;
            tsk.step3.flow_step3_pipeline_steps_kpis_analysis_dates = this.flow_step3_pipeline_steps_kpis_analysis_dates;
            tsk.step3.flow_step3_pipeline_steps_files_export_features = this.flow_step3_pipeline_steps_files_export_features;
            tsk.step3.flow_step3_pipeline_steps_files_export_thresholds = this.flow_step3_pipeline_steps_files_export_thresholds;
            tsk.step3.flow_step3_pipeline_steps_files_export_parameters = this.flow_step3_pipeline_steps_files_export_parameters;
            tsk.step3.flow_step3_pipeline_steps_files_export_transactions = this.flow_step3_pipeline_steps_files_export_transactions;
            tsk.step3.flow_step3_pipeline_steps_files_export_clusters = this.flow_step3_pipeline_steps_files_export_clusters;
            tsk.step3.flow_step3_pipeline_steps_files_export_alerts = this.flow_step3_pipeline_steps_files_export_alerts;

            tsk.step4 = {};
            tsk.step4.flow_step4_skip = this.flow_step4_skip;
            tsk.step4.flow_step4_experiment_key = this.flow_step4_experiment_key;
            tsk.step4.flow_step4_cluster_key = this.flow_step4_cluster_key;
            tsk.step4.flow_step4_pipeline_steps_data_serialization_alerts_serialisation = this.flow_step4_pipeline_steps_data_serialization_alerts_serialisation;
            tsk.step4.flow_step4_pipeline_steps_data_serialization_transactions_serialisation = this.flow_step4_pipeline_steps_data_serialization_transactions_serialisation;
            tsk.step4.flow_step4_pipeline_steps_data_serialization_amlit_alerts_serialisation = this.flow_step4_pipeline_steps_data_serialization_amlit_alerts_serialisation;
            tsk.step4.flow_step4_pipeline_steps_data_serialization_lookback_sums = this.flow_step4_pipeline_steps_data_serialization_lookback_sums;
            tsk.step4.flow_step4_pipeline_steps_alerting_transactions = this.flow_step4_pipeline_steps_alerting_transactions;
            tsk.step4.flow_step4_pipeline_steps_alerting_prod_alerts = this.flow_step4_pipeline_steps_alerting_prod_alerts;
            tsk.step4.flow_step4_pipeline_steps_alerting_prod_alerts_key = this.flow_step4_pipeline_steps_alerting_prod_alerts_key;
            tsk.step4.flow_step4_pipeline_steps_alerting_parameters = this.flow_step4_pipeline_steps_alerting_parameters;
            tsk.step4.flow_step4_pipeline_steps_alerting_lookback_sums = this.flow_step4_pipeline_steps_alerting_lookback_sums;
            tsk.step4.flow_step4_pipeline_steps_alerting_thresholds = this.flow_step4_pipeline_steps_alerting_thresholds;
            tsk.step4.flow_step4_pipeline_steps_alerting_analysis_dates = this.flow_step4_pipeline_steps_alerting_analysis_dates;
            tsk.step4.flow_step4_pipeline_steps_kpis_transactions = this.flow_step4_pipeline_steps_kpis_transactions;
            tsk.step4.flow_step4_pipeline_steps_kpis_alerts = this.flow_step4_pipeline_steps_kpis_alerts;
            tsk.step4.flow_step4_pipeline_steps_kpis_baseline = this.flow_step4_pipeline_steps_kpis_baseline;
            tsk.step4.flow_step4_pipeline_steps_kpis_parameters = this.flow_step4_pipeline_steps_kpis_parameters;
            tsk.step4.flow_step4_pipeline_steps_kpis_analysis_dates = this.flow_step4_pipeline_steps_kpis_analysis_dates;

            tsk.step5 = {};
            tsk.step5.flow_step5_skip = this.flow_step5_skip;
            tsk.step5.flow_step5_experiment_key = this.flow_step5_experiment_key;
            tsk.step5.flow_step5_pipeline_steps_files_export_features = this.flow_step5_pipeline_steps_files_export_features;
            tsk.step5.flow_step5_pipeline_steps_files_export_thresholds = this.flow_step5_pipeline_steps_files_export_thresholds;
            tsk.step5.flow_step5_pipeline_steps_files_export_parameters = this.flow_step5_pipeline_steps_files_export_parameters;
            tsk.step5.flow_step5_pipeline_steps_files_export_transactions = this.flow_step5_pipeline_steps_files_export_transactions;
            tsk.step5.flow_step5_pipeline_steps_files_export_clusters = this.flow_step5_pipeline_steps_files_export_clusters;
            tsk.step5.flow_step5_pipeline_steps_files_export_alerts = this.flow_step5_pipeline_steps_files_export_alerts;

            tsk.rollback = {};
            tsk.rollback.flow_rollback_delete_input_cache = this.flow_rollback_delete_input_cache;
            tsk.rollback.flow_rollback_delete_kyc_cache = this.flow_rollback_delete_kyc_cache;
            tsk.rollback.flow_rollback_delete_output_cache = this.flow_rollback_delete_output_cache;
            return tsk;
        },
        get_gcars_report_list() {
            const path = this.$store.state.backendUrl + "gcars-report-list";
            axios
                .get(path)
                .then((res) => {
                    this.gcars_report_list = res.data;
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.error(error);
                });
        },

        get_sensitivity_report_list() {
            const path = this.$store.state.backendUrl + "sensitivity-report-list";
            axios
                .get(path)
                .then((res) => {
                    this.sensitivity_report_list = res.data;
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.error(error);
                });
        },

        get_kyc_reliance_worldwide_report_list() {
            const path = this.$store.state.backendUrl + "kyc-reliance-worldwide-report-list";
            axios
                .get(path)
                .then((res) => {
                    this.kyc_reliance_worldwide_report_list = res.data;
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.error(error);
                });
        },

        get_country_risk_report_list() {
            const path = this.$store.state.backendUrl + "country-risk-report-list";
            axios
                .get(path)
                .then((res) => {
                    this.country_risk_report_list = res.data;
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.error(error);
                });
        },

        get_actimize_version_list() {
            const path = this.$store.state.backendUrl + "actimize-version-list";
            axios
                .get(path)
                .then((res) => {
                    this.actimize_version_list = res.data;
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.error(error);
                });
        },

        get_models_list() {
            const path = this.$store.state.backendUrl + "models-list";
            axios
                .get(path)
                .then((res) => {
                    this.models_list = res.data;
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.error(error);
                });
        },

        get_business_unit_list() {
            const path = this.$store.state.backendUrl + "business-unit-list";
            axios
                .get(path)
                .then((res) => {
                    this.business_unit_list = res.data;
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.error(error);
                });
        },

        get_bucket_mapping_mode_list() {
            const path = this.$store.state.backendUrl + "bucket-mapping-mode-list";
            axios
                .get(path)
                .then((res) => {
                    this.bucket_mapping_mode_list = res.data;
                })
                .catch((error) => {
                    // eslint-disable-next-line
                    console.error(error);
                });
        },

        getClasses: (size, success, error) => {
            let sizeValue, isValidValue;

            sizeValue = size ? `form-control-${size}` : null;

            if (error) {
                isValidValue = "is-invalid";
            } else if (success) {
                isValidValue = "is-valid";
            } else {
                isValidValue = "";
            }

            return `${sizeValue} ${isValidValue}`;
        },
        getIcon: (icon) => (icon ? icon : null),
        hasIcon: (icon) => (icon ? "input-group" : null),
        getFlowSpecs() {
          const path = this.$store.state.backendUrl + 'load-flow-specs/' + this.uuid;
          axios.get(path)
            .then((res) => {
              this.specs = res.data.specs;
              this.update_model();
              this.flow_startup_download_files = false;
            })
            .catch((error) => {
              console.error(error);
            });
        },
        load_clusters() {
          const path = this.$store.state.backendUrl + 'task/clusters/' + this.uuid;
          axios.get(path)
            .then((res) => {
              this.clusters = res.data;
            })
            .catch((error) => {
              console.error(error);
            });
        },
        check(x){
            if (x == true){
                return "checked";
            }
            return "";
        },
        startFlow() {

            const cswal = this.$swal.mixin({
                customClass: {
                    htmlContainer: "in"
                }
            });
            cswal
                .fire({
                    title: "Run Simulation",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Run Simulation",
                    html: `
                <div style="text-align: left;">
                    <input style="height: 0.625em" id="swal-input1" class="swal2-input" type ="checkbox" ${this.check(this.flow_step0_skip)}>
                    <label> Serialization</label><br>
                    <input style="height: 0.625em" id="swal-input2" class="swal2-input" type="checkbox" ${this.check(this.flow_step1_skip)}>
                    <label> Feature Engineering</label><br>
                    <input style="height: 0.625em" id="swal-input3" class="swal2-input" type="checkbox" ${this.check(this.flow_step2_skip)}>
                    <label> Clustering</label><br>
                    <input style="height: 0.625em" id="swal-input4" class="swal2-input" type="checkbox" ${this.check(this.flow_step3_skip)}>
                    <label> Step 3</label><br>
                    <input style="height: 0.625em" id="swal-input5" class="swal2-input" type="checkbox" ${this.check(this.flow_step4_skip)}>
                    <label> Step 4</label><br>
                    <input style="height: 0.625em" id="swal-input6" class="swal2-input" type="checkbox" ${this.check(this.flow_step5_skip)}>
                    <label> Step 5</label><br>
                </div>
                `,
                    focusConfirm: false
                })
                .then(result => {
                    this.flow_step0_skip = !document.getElementById("swal-input1").checked
                    this.flow_step1_skip = !document.getElementById("swal-input2").checked
                    this.flow_step2_skip = !document.getElementById("swal-input3").checked
                    this.flow_step3_skip = !document.getElementById("swal-input4").checked
                    this.flow_step4_skip = !document.getElementById("swal-input5").checked
                    this.flow_step5_skip = !document.getElementById("swal-input6").checked


                    if (result.isConfirmed) {
                        const path = this.$store.state.backendUrl + "tasks";
                        const formData = new FormData();
                        formData.append('bucketsFile', this.bucketsFile);
                        formData.append('thresholdParametersFile', this.thresholdParametersFile);
                        const mod = this.export_model() ;

                        if (this.settings_button_caption === "Restart Flow"){
                            formData.append('isNew', false);
                            formData.append('uuid', this.uuid);
                        }else{
                            formData.append('isNew', true);
                            formData.append('uuid', "");
                        }
                        formData.append("flow_specs",JSON.stringify(mod))
                        axios
                            .post(
                                path,
                                formData,
                                {
                                    headers: {
                                      'Content-Type': 'multipart/form-data'
                                    }
                                }
                            )
                            .then((res) => {
                                console.log(res);

                                let timerInterval;
                                this.$swal.fire({
                                  title: 'Creating new Flow',
                                  html: 'Initialization complete in <b></b> milliseconds.',
                                  timer: 10000,
                                  timerProgressBar: true,
                                  didOpen: () => {
                                    this.$swal.showLoading()
                                    const b = this.$swal.getHtmlContainer().querySelector('b')
                                    timerInterval = setInterval(() => {
                                      b.textContent = this.$swal.getTimerLeft()
                                    }, 100)
                                  },
                                  willClose: () => {
                                    clearInterval(timerInterval)
                                  }
                                }).then((result) => {
                                  /* Read more about handling dismissals below */
                                  if (result.dismiss === this.$swal.DismissReason.timer) {
                                    this.$router.push({ path: "/flows/" + res.data.task_id });
                                  }
                                })

                            })
                            .catch((error) => {
                                console.error(error);
                            });

                    }
                });


        },
    },

    mounted() {
        if(this.flow_specs){
            this.getFlowSpecs();
        }
    },
    created() {
        this.get_gcars_report_list();
        this.get_sensitivity_report_list();
        this.get_kyc_reliance_worldwide_report_list();
        this.get_country_risk_report_list();
        this.get_actimize_version_list();
        this.get_models_list();
        this.get_business_unit_list();
        this.get_bucket_mapping_mode_list();
        this.load_clusters();
    },
};
