
import ArchiveCardDetailed from "@/views/components/archive_card_detailed/ArchiveCardDetailed.vue";

export default {
  name: "tables",

  components: {
    ArchiveCardDetailed,
  },
};
