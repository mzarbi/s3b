import setTooltip from "@/assets/js/tooltip.js";
import VsudProgress from "@/views/ccmp/simple/VsudProgress.vue";
import img1 from "@/assets/img/small-logos/logo-xd.svg";
import img2 from "@/assets/img/team-1.jpg";
import img3 from "@/assets/img/team-2.jpg";
import img4 from "@/assets/img/team-3.jpg";
import img5 from "@/assets/img/team-4.jpg";
import img6 from "@/assets/img/small-logos/logo-atlassian.svg";
import img7 from "@/assets/img/team-2.jpg";
import img8 from "@/assets/img/team-4.jpg";
import img9 from "@/assets/img/small-logos/logo-slack.svg";
import img10 from "@/assets/img/team-3.jpg";
import img11 from "@/assets/img/team-1.jpg";
import img12 from "@/assets/img/small-logos/logo-spotify.svg";
import img13 from "@/assets/img/team-4.jpg";
import img14 from "@/assets/img/team-3.jpg";
import img15 from "@/assets/img/team-4.jpg";
import img16 from "@/assets/img/team-1.jpg";
import img17 from "@/assets/img/small-logos/logo-jira.svg";
import img18 from "@/assets/img/team-4.jpg";
import img19 from "@/assets/img/small-logos/logo-invision.svg";
import img20 from "@/assets/img/team-1.jpg";
import img21 from "@/assets/img/team-4.jpg";
import axios from 'axios';

export default {
  name: "projects-card",
  data() {
    return {
      tasks : [],
      img1,
      img2,
      img3,
      img4,
      img5,
      img6,
      img7,
      img8,
      img9,
      img10,
      img11,
      img12,
      img13,
      img14,
      img15,
      img16,
      img17,
      img18,
      img19,
      img20,
      img21,
    };
  },
  methods: {
    task_url(task){
        return "flows/" + task.uuid;
    },
    compute_percentage(task){
        if(task.state == "SUCCESS"){
            return 100;
        }
        if(task.state == "PROGRESS"){
            return 0;
        }
        return 0;
    },
    getTasks() {
      const path = this.$store.state.backendUrl + 'tasks';
      axios.get(path)
        .then((res) => {
          this.tasks = res.data.slice(0, 5);
        })
        .catch((error) => {
          console.error(error);
        });
    },
  },
  created() {
    this.getTasks();
  },
  components: {
    VsudProgress,
  },
  mounted() {
    setTooltip();

  },

};