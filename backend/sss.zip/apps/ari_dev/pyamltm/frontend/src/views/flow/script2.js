
import MiniStatisticsCard2 from "@/views/ccmp/composite/Cards/MiniStatisticsCard2.vue";
import GradientLineChart from "@/views/ccmp/composite/Charts/GradientLineChart.vue";
import ReportsBarChart from "@/views/ccmp/composite/Charts/ReportsBarChart.vue";
import ProjectsCard from "@/views/components/projects_card/ProjectsCard.vue";
import Tabs from "@/views/ccmp/composite/Tabs/Tabs.vue";
import Tab from "@/views/ccmp/composite/Tabs/Tab.vue";
import Tree from "@/views/ccmp/composite/Tree/Tree";
import TreeMenu from '@/views/ccmp/composite/Tree/Tree2.vue'
import FlowSettings from "@/views/flow_settings/FlowSettings.vue";
import {
  faHandPointer,
  faUsers,
  faCreditCard,
  faScrewdriverWrench,
} from "@fortawesome/free-solid-svg-icons";
import TimelineList from "@/views/components/TimelineList.vue";
import TimelineItem from "@/views/components/TimelineItem.vue";

import axios from 'axios';
export default {
  name: "tables",
  data() {
    return {
      tree2 : {},
      settings_button_caption: "Restart Flow",
      flow_specs: true,
      uuid : this.$route.params.uuid,
      kpis: [],
      childDataLoaded: false,
      chart_values: {},
      task: {},
      logs: "",
      iconBackground: "bg-gradient-success",
      faCreditCard,
      faScrewdriverWrench,
      faUsers,
      faHandPointer
    };
  },
  methods: {
    add2archive(event){
        if (event) {
          this.$swal.fire({
              title: 'Are you sure?',
              text: "You can restore this run after archiving it",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, archive it!'
            }).then((result) => {
              if (result.isConfirmed) {
                  const uuid = event.target.value;
                  const path = this.$store.state.backendUrl + 'task/archive/' + this.$route.params.uuid;
                  axios.get(path).then((res) => {
                      this.$router.push('/flow-explorer')
                  }).catch((error) => {
                      console.error(error);
                  });
              }
            });

        }
    },
    description(){
        if(this.task.state == "SUCCESS"){
            return "<i class='fa fa-arrow-up text-success' aria-hidden='true'></i><span class='font-weight-bold'> " + this.task.state + "</span>";
        }else{
            return "<i class='fa fa-arrow-down text-failure' aria-hidden='true'></i><span class='font-weight-bold'> " + this.task.state + "</span>"
        }
    },
    compute_percentage(task){
        if(task.task_status == "SUCCESS"){
            return 100;
        }
        if(task.task_status == "PROGRESS"){
            return task.task_result.percentage;
        }
        return 0;
    },
    getTask() {
      const path = this.$store.state.backendUrl + 'task/raw/' + this.uuid;
      axios.get(path)
        .then((res) => {

          this.task = res.data;
          var last_task = this.task.breakpoints[this.task.breakpoints.length - 1]
          if (last_task.name == "Rollback"){
            this.task.state = "Failure"
          }
          if (last_task.name == "Manual Lock"){
            this.$swal.fire({
                title: "This flow require manual input to complete all steps, you to update the manual lock step parameters",
                showDenyButton: false,
                showCancelButton: false,
                confirmButtonText: "Proceed",
            });
          }


        })
        .catch((error) => {
          console.error(error);
        });
    },
    getKpis() {
      const path = this.$store.state.backendUrl + 'fast-kpis/' + this.uuid;
      axios.get(path)
        .then((res) => {
          this.kpis = res.data;
        })
        .catch((error) => {
          // eslint-disable-next-line
          console.error(error);
        });
    },

    getDashboardChartValues() {
      const path = this.$store.state.backendUrl + 'dashboard-chart/' + this.uuid;
      axios.get(path)
        .then((res) => {
          this.childDataLoaded = true;
          this.chart_values = res.data;
          console.log(res.data);
        })
        .catch((error) => {
          console.error(error);
        });
    },

    getFileSystem() {
      const path = this.$store.state.backendUrl + 'file-system/' + this.uuid;
      axios.get(path)
        .then((res) => {
          this.tree2 = res.data;
        })
        .catch((error) => {
          console.error(error);
        });
    },

    getLogs() {
      const path = this.$store.state.backendUrl + 'logs/' + this.uuid;
      axios.get(path)
        .then((res) => {
          this.logs = res.data;
        })
        .catch((error) => {
          console.error(error);
        });
    },
  },

  mounted(){
    this.getDashboardChartValues();
  },
  created() {
    const path = this.$store.state.backendUrl + 'check_task/' + this.uuid;
    axios.get(path)
    .then((res) => {
      if (res.data.status){
        this.getKpis();
        this.getFileSystem();
        this.getTask();
        this.getLogs();
      }else{
        this.$swal.fire({
                title: "Task is not yet accessible.",
                showDenyButton: false,
                showCancelButton: false,
                confirmButtonText: "Go To The Flow Explorer",
            }).then((result) => {
              if (result.isConfirmed) {
                this.$router.push('/flow-explorer')
              }
            });
      }
    })
    .catch((error) => {
      console.error(error);
    });
  },
  components: {
    MiniStatisticsCard2,
    GradientLineChart,
    ProjectsCard,
    Tab,
    Tabs,
    Tree,
    TreeMenu,
    FlowSettings,
    TimelineList,TimelineItem,ReportsBarChart
  },
};
