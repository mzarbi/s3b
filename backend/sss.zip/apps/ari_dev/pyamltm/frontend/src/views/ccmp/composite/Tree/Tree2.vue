<template>
<div class="tree-menu">
    <div class="label-wrapper" @click="toggleChildren">
      <div :style="indent" :class="labelClasses" class="tree-item">
        <span v-if="nodes">&#128193;</span>
        <span v-else @click="downloadItem()">&#128240;</span>
        {{ label }}
      </div>
    </div>
    <template v-if="showChildren">
    <tree-menu
      v-for="node in nodes"
      :nodes="node.nodes"
      :label="node.label"
      :depth="depth + 1"
      :absolute_url="node.absolute_url"
      :key="node.id"
    >
    </tree-menu>
    </template>
  </div>
</template>
<script>
import axios from 'axios';

  export default {
    props: [ 'label', 'nodes', 'depth', 'absolute_url' ],
    data() {
      return { showChildren: false }
    },
    name: 'tree-menu',
    computed: {
      indent() {
        return { transform: `translate(${this.depth * 30}px)` }
      }
    },
    methods: {
      downloadItem () {

        if (this.absolute_url.includes("INPUT")){

            this.$swal.fire({
              icon: 'error',
              title: 'Authorization Error',
              text: 'Data Governance prevents you from downloading this file!',
            })

        }else{
            axios.get(this.absolute_path(), { responseType: 'blob' })
          .then(response => {
            const blob = new Blob([response.data], { type: 'application/file' })
            const link = document.createElement('a')
            link.href = URL.createObjectURL(blob)
            link.download = this.label
            link.click()
            URL.revokeObjectURL(link.href)

          }).catch(console.error)
        }

      },
      absolute_path(){
        return this.$store.state.backendUrl + "file/" + btoa(this.absolute_url);
      },
      toggleChildren() {
        this.showChildren = !this.showChildren;
      }
    }
  }
</script>
<style>
body {
  font-family: "Open Sans", sans-serif;
  font-size: 18px;
  font-weight: 300;
  line-height: 1em;
}

.container {
  margin: 0 auto;
}

.tree-menu {
  .label-wrapper {
    padding-bottom: 10px;
    margin-bottom: 10px;
    border-bottom: 1px solid #ccc;
    .has-children {
      cursor: pointer;
    }
  }
}

.tree-item{
    cursor: pointer
}
.tree-item:hover{
    opacity : 0.6
}
</style>