<template src="./template2.html"></template>
<style src="./style.css"></style>
<script src="./script2.js"></script>
