import './scss/main.scss';
export { default as GDialog } from './components/GDialog.vue';
export type { IDialog, } from './types/Plugin';
export { default as GDialogRoot } from './components/GDialogRoot.vue';
export { plugin, dialogInjectionKey, } from './plugin';
//# sourceMappingURL=index.d.ts.map