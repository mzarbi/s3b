declare const _default: import("vue").DefineComponent<{}, {
    dialogs: import("../types/Plugin").IDialogItem[];
    onClose: (index: number) => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, import("vue").EmitsOptions, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}>;
export default _default;
//# sourceMappingURL=GDialogRoot.vue.d.ts.map