import type { Ref } from 'vue';
export declare function useOverlay(isActive: Ref<boolean | undefined>): {
    zIndex: Ref<number>;
};
//# sourceMappingURL=overlay.d.ts.map