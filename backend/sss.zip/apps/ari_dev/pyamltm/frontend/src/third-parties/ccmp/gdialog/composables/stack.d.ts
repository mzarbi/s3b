import type { Ref } from 'vue';
export declare function useStack(isActive: Ref<boolean>): {
    isTop: import("vue").ComputedRef<boolean>;
};
//# sourceMappingURL=stack.d.ts.map