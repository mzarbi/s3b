module.exports = {
    publicPath: '',
    "transpileDependencies": [
      "vuetify"
    ],
    pages: {
      index: {
        entry: 'src/main.js',
        title: 'AMLTM'
      }
    }
  }