import json
import os
import yaml
from dotenv import load_dotenv
import pkgutil

load_dotenv()


def load_json(path: str):
    with open(path, "r") as f:
        return json.load(f)


def load_yaml(path: str):
    with open(path, "r") as f:
        return yaml.load(f, Loader=yaml.FullLoader)


def load_json_from_local_resources(name: str):
    return json.loads(pkgutil.get_data(__name__, name))


def load_yaml_from_local_resources(name: str):
    return yaml.load(pkgutil.get_data(__name__, name), Loader=yaml.FullLoader)


def load_json_from_resources(name: str):
    path = os.path.join(os.environ["RESOURCES_PATH"], name)
    return load_json(path)


def load_yaml_from_resources(name: str):
    path = os.path.join(os.environ["RESOURCES_PATH"], name)
    return load_yaml(path)
