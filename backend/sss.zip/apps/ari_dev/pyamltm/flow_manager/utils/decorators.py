import logging
import os
from functools import wraps
from re import search
import pickle
import time
from threading import current_thread

import pandas as pd
from flow_manager.utils.converters import convert

LOGGER = logging.getLogger(__name__)
INDENTATION_STEP = 2


def singleton(cls):
    """Make a class a Singleton class (only one instance)"""

    @wraps(cls)
    def wrapper_singleton(*args, **kwargs):
        if not wrapper_singleton.instance:
            wrapper_singleton.instance = cls(*args, **kwargs)
        return wrapper_singleton.instance

    wrapper_singleton.instance = None
    return wrapper_singleton


def is_match(_lambda, pattern):
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            if callable(_lambda) and search(pattern, (_lambda(self) or '')):
                f(self, *f_args, **f_kwargs)

        return wrapped

    return wrapper


def skippable():
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            if not self.mark_as_ignored:
                f(self, *f_args, **f_kwargs)

        return wrapped

    return wrapper


def decorate(name, indent=0, show_delta=True):
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            time.sleep(0.3)
            start_time = time.time()
            info(name, indent, delay=False)
            res = f(self, *f_args, **f_kwargs)
            if show_delta:
                info(name + " finished with success %s s" % (time.time() - start_time), indent, delay=False)
            return res

        return wrapped

    return wrapper


def cache_parquet(name, path, indent=0, show_delta=True):
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            start_time = time.time()
            info(name, indent)
            if os.path.isfile(path):
                return pd.read_parquet(path)
            res = f(self, *f_args, **f_kwargs)
            if show_delta:
                info(name + " finished with success %s s" % (time.time() - start_time), indent)
            if res is not None:
                res.to_parquet(path)
            return res

        return wrapped

    return wrapper


def cache(pattern, name, indent=0, format="pickle"):
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            start_time = time.time()
            info(name, indent)
            cch = load_cache(self.breakpoint_path + "/" + pattern, format)
            if cch is not None:
                info(name + " cache loaded with success %s s" % (time.time() - start_time), indent)
                return cch
            else:
                res = f(self, *f_args, **f_kwargs)
                save_cache(res, self.breakpoint_path + "/" + pattern, format)
                info(name + " finished with success %s s" % (time.time() - start_time), indent)
                return res

        return wrapped

    return wrapper


def save_cache(res, pth, format):
    if format == "pickle":
        return save_pickle(res, pth)


def save_pickle(res, pth):
    with open(pth, "wb") as f:
        pickle.dump(res, f)


def load_cache(pth, format):
    if not os.path.isfile(pth):
        return None
    if format == "pickle":
        return load_pickle(pth)


def load_pickle(pth):
    with open(pth, "rb") as f:
        return pickle.load(f)


def log(v, indent=0):
    thread = current_thread()
    logger = LOGGER
    if hasattr(thread, 'uuid'):
        try:
            logger = create_log_handler(thread.uuid)
        except:
            logger = LOGGER

    if convert(os.environ["LOGGING"], "bool"):
        logger.log(indent * INDENTATION_STEP * " " + v)


def info(v, indent=0, delay=True):
    thread = current_thread()
    logger = LOGGER
    if hasattr(thread, 'uuid'):
        try:
            logger = create_log_handler(thread.uuid)
        except:
            logger = LOGGER
    if convert(os.environ["LOGGING"], "bool"):
        logger.info(indent * INDENTATION_STEP * " " + v)
        if delay:
            time.sleep(0.1)


def exception(v, indent=0, delay=True):
    thread = current_thread()
    logger = LOGGER
    if hasattr(thread, 'uuid'):
        try:
            logger = create_log_handler(thread.uuid)
        except:
            logger = LOGGER
    if convert(os.environ["LOGGING"], "bool"):
        logger.exception(indent * INDENTATION_STEP * " " + v)
        if delay:
            time.sleep(0.1)


def warn(v, indent=0):
    thread = current_thread()
    logger = LOGGER
    if hasattr(thread, 'uuid'):
        try:
            logger = create_log_handler(thread.uuid)
        except:
            logger = LOGGER
    if convert(os.environ["LOGGING"], "bool"):
        logger.warning(indent * INDENTATION_STEP * " " + v)


def error(v, indent=0):
    thread = current_thread()
    logger = LOGGER
    if hasattr(thread, 'uuid'):
        try:
            logger = create_log_handler(thread.uuid)
        except:
            logger = LOGGER
    if convert(os.environ["LOGGING"], "bool"):
        logger.error(indent * INDENTATION_STEP * " " + v)


def create_log_handler(fname):
    logger = logging.getLogger(name=fname)
    if (logger.hasHandlers()):
        logger.handlers.clear()
    pth = os.path.join(os.environ["CACHE_PATH"], fname, "debug.log")
    fileHandler = logging.FileHandler(pth)
    logger.addHandler(fileHandler)
    formatter = logging.Formatter('%(name)s %(levelname)s: %(message)s')
    fileHandler.setFormatter(formatter)
    return logger
