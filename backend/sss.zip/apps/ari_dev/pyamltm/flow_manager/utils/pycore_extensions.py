import json
import os
import shutil
from datetime import datetime
from common.io.s3 import S3Manager
from common.parameters import S3ObjectDeletionReason


class S3ManagerExtension(S3Manager):
    def __init__(self, project, environment, layer, access_right='RW'):
        super().__init__(project, environment, layer, access_right='RW')
        self.app_cache = "AMLCM/APP_CACHE"
        self.manifest_key = f"{self.app_cache}/manifest.json"

    def create_folder(self, directory_name):
        self.client.put_object(Bucket=self.bucket_name, Key=(directory_name + '/'))

    def list_s3_files(self, prefix):
        """
        This functions list all files in s3 bucket.
        :return: None
        """
        response = self.client.list_objects_v2(Bucket=self.bucket_name, Prefix=prefix)
        files = response.get("Contents")
        return files

    def read_json(self, object_key, *args, **kwargs):
        obj = self.client.get_object(Bucket=self.bucket_name, Key=object_key)
        js_ = obj['Body'].read().decode('utf-8')
        return json.loads(js_)

    def write_json(self, dc, object_key, *args, **kwargs):
        self.client.put_object(
            Bucket=self.bucket_name, Body=json.dumps(dc), Key=object_key
        )

    def manifest_exist(self):
        return self.is_file(self.manifest_key)

    def manifest_empty(self):
        if not self.manifest_exist():
            return True
        if self.read_manifest() is None:
            self.clear_manifest()
        return len(self.read_manifest().get("flows", [])) == 0

    def read_manifest(self):
        return self.read_json(self.manifest_key)

    def write_manifest(self, dc):
        self.write_json(dc, self.manifest_key)

    def clear_manifest(self):
        manifest = {"flows": []}
        self.write_manifest(manifest)

    def push(self, uuid, business_unit, name):
        cache_path = os.environ.get("CACHE_PATH",r"D:\apps\ari_dev\pyamltm\cache")
        pth = os.path.join(cache_path, uuid)
        os.makedirs(os.path.join(cache_path, "SYNC_TMP"), exist_ok=True)
        shutil.make_archive(
            os.path.join(cache_path, "SYNC_TMP", uuid), 'zip',
            os.path.join(pth)
        )

        self.create_folder(
            f"AMLCM/APP_CACHE/" + business_unit
        )
        self.upload_file(
            os.path.join(cache_path, "SYNC_TMP", uuid + ".zip"),
            f"AMLCM/APP_CACHE/" + business_unit + "/" + uuid + ".zip"
        )
        os.remove(os.path.join(cache_path, "SYNC_TMP", uuid + ".zip"))
        dc = {
            "uuid": uuid,
            "name": name,
            "business_unit": business_unit,
            "date": datetime.now().strftime("%d-%b-%Y (%H:%M:%S.%f)")
        }
        manifest = self.read_manifest()
        manifest["flows"].append(dc)
        self.write_manifest(manifest)

    def pull(self, uuid, business_unit):
        cache_path = os.environ.get("CACHE_PATH",r"D:\apps\ari_dev\pyamltm\cache")
        self.download_file(
            f"AMLCM/APP_CACHE/" + business_unit + "/" + uuid + ".zip",
            os.path.join(cache_path, "SYNC_TMP",uuid + ".zip")
        )
        os.makedirs(os.path.join(cache_path, uuid),exist_ok=True)
        shutil.unpack_archive(
            os.path.join(cache_path, "SYNC_TMP",uuid + ".zip"),
            os.path.join(cache_path,uuid),
            "zip"
        )
        os.remove(os.path.join(cache_path, "SYNC_TMP", uuid + ".zip"))


if __name__ == "__main__":
    s3mr = S3ManagerExtension('gb', 'dev', 'raw')


    # hndlr.push("52d82980-43a0-4530-944e-195f291ca41d","BGR","FLOW_94019459")
    # hndlr.clear_manifest()
    #mn = s3mr.read_manifest()
    #mn["flows"].append("sdsds")
    s3mr.write_manifest({'flows': [{'uuid': '52d82980-43a0-4530-944e-195f291ca41d', 'name': 'FLOW_94019459', 'business_unit': 'ARE', 'date': '26-Aug-2022 (06:50:52.661504)'}]}
)
    print(s3mr.read_manifest())
    #s3mr.pull("52d82980-43a0-4530-944e-195f291ca41d", "BGR")
    #s3mr.delete_file("AMLCM/APP_CACHE/manifest.json",S3ObjectDeletionReason.Cleanup)

    def list(s3mr):
        ls = s3mr.list_s3_files(f"AMLCM/APP_CACHE")
        for i in ls:
            print(i["Key"])


    list(s3mr)
