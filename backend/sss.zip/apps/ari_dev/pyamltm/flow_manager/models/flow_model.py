# To use this code, make sure you
#
#     import json
#
# and then, to convert JSON from a string, do
#
#     result = flow_model_from_dict(json.loads(json_string))

from dataclasses import dataclass
from datetime import datetime
from typing import Any, List, Optional, TypeVar, Callable, Type, cast

import dateutil

T = TypeVar("T")


def from_int(x: Any) -> int:
    assert isinstance(x, int) and not isinstance(x, bool)
    return x


def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


def from_bool(x: Any) -> bool:
    assert isinstance(x, bool)
    return x


def from_none(x: Any) -> Any:
    assert x is None
    return x


def from_union(fs, x):
    for f in fs:
        try:
            return f(x)
        except:
            pass
    assert False


def from_float(x: Any) -> float:
    assert isinstance(x, (float, int)) and not isinstance(x, bool)
    return float(x)


def to_float(x: Any) -> float:
    assert isinstance(x, float)
    return x


def from_datetime(x: Any) -> datetime:
    return dateutil.parser.parse(x)


@dataclass
class Maintainer:
    name: str
    email: str

    @staticmethod
    def from_dict(obj: Any) -> 'Maintainer':
        assert isinstance(obj, dict)
        name = from_str(obj.get("name"))
        email = from_str(obj.get("email"))
        return Maintainer(name, email)

    def to_dict(self) -> dict:
        result: dict = {}
        result["name"] = from_str(self.name)
        result["email"] = from_str(self.email)
        return result


@dataclass
class CustomSlot:
    name: str
    on_true: str
    on_false: str

    @staticmethod
    def from_dict(obj: Any) -> 'CustomSlot':
        assert isinstance(obj, dict)
        name = from_str(obj.get("name"))
        on_true = from_str(obj.get("on_true"))
        on_false = from_str(obj.get("on_false"))
        return CustomSlot(name, on_true, on_false)

    def to_dict(self) -> dict:
        result: dict = {}
        result["name"] = from_str(self.name)
        result["on_true"] = from_str(self.on_true)
        result["on_false"] = from_str(self.on_false)
        return result


@dataclass
class Slots:
    custom_slots: List[CustomSlot]
    on_success: str
    on_failure: str

    @staticmethod
    def from_dict(obj: Any) -> 'Slots':
        assert isinstance(obj, dict)
        custom_slots = from_list(CustomSlot.from_dict, obj.get("custom_slots"))
        on_success = from_str(obj.get("on_success"))
        on_failure = from_str(obj.get("on_failure"))
        return Slots(custom_slots, on_success, on_failure)

    def to_dict(self) -> dict:
        result: dict = {}
        result["custom_slots"] = from_list(lambda x: to_class(CustomSlot, x), self.custom_slots)
        result["on_success"] = from_str(self.on_success)
        result["on_failure"] = from_str(self.on_failure)
        return result


@dataclass
class Task:
    marker: str
    class_name: str
    description: str
    cached: bool
    task_cfg: dict
    slots: Slots
    sub_tasks: Optional[List['Task']] = None

    @staticmethod
    def from_dict(obj: Any) -> 'Task':
        assert isinstance(obj, dict)
        marker = from_str(obj.get("marker"))
        class_name = from_str(obj.get("class_name"))
        description = from_str(obj.get("description"))
        cached = from_bool(obj.get("cached"))
        task_cfg = obj.get("task_cfg")
        slots = Slots.from_dict(obj.get("slots"))
        sub_tasks = from_union([lambda x: from_list(Task.from_dict, x), from_none], obj.get("sub_tasks"))
        return Task(marker, class_name, description, cached, task_cfg, slots, sub_tasks)

    def to_dict(self) -> dict:
        result: dict = {}
        result["marker"] = from_str(self.marker)
        result["class_name"] = from_str(self.class_name)
        result["description"] = from_str(self.description)
        result["cached"] = from_bool(self.cached)
        result["task_cfg"] = self.task_cfg
        result["slots"] = to_class(Slots, self.slots)
        result["sub_tasks"] = from_union([lambda x: from_list(lambda x: to_class(Task, x), x), from_none],
                                         self.sub_tasks)
        return result


@dataclass
class FlowModel:
    name: str
    maintainer: Maintainer
    flow_cfg: dict
    entry_point: str
    tasks: List[Task]

    @staticmethod
    def from_dict(obj: Any) -> 'FlowModel':
        assert isinstance(obj, dict)
        name = from_str(obj.get("name"))
        maintainer = Maintainer.from_dict(obj.get("maintainer"))
        flow_cfg = obj.get("flow_cfg")
        entry_point = from_str(obj.get("entry_point"))
        tasks = from_list(Task.from_dict, obj.get("tasks"))
        return FlowModel(name, maintainer, flow_cfg, entry_point, tasks)

    def to_dict(self) -> dict:
        result: dict = {}
        result["name"] = from_str(self.name)
        result["maintainer"] = to_class(Maintainer, self.maintainer)
        result["flow_cfg"] = self.flow_cfg
        result["entry_point"] = from_str(self.entry_point)
        result["tasks"] = from_list(lambda x: to_class(Task, x), self.tasks)
        return result


def flow_model_from_dict(s: Any) -> FlowModel:
    return FlowModel.from_dict(s)


def flow_model_to_dict(x: FlowModel) -> Any:
    return to_class(FlowModel, x)
