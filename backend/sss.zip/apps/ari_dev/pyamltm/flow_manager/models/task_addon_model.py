# To use this code, make sure you
#
#     import json
#
# and then, to convert JSON from a string, do
#
#     result = task_addon_model_from_dict(json.loads(json_string))

from dataclasses import dataclass
from typing import List, Optional, Any, TypeVar, Callable, Type, cast


T = TypeVar("T")


def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def from_none(x: Any) -> Any:
    assert x is None
    return x


def from_union(fs, x):
    for f in fs:
        try:
            return f(x)
        except:
            pass
    assert False


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


@dataclass
class TaskAddonModel:
    class_name: str
    description: str
    custom_slots: List[str]
    sub_tasks: Optional[List['TaskAddonModel']] = None

    @staticmethod
    def from_dict(obj: Any) -> 'TaskAddonModel':
        assert isinstance(obj, dict)
        class_name = from_str(obj.get("class_name"))
        description = from_str(obj.get("description"))
        custom_slots = from_list(from_str, obj.get("custom_slots"))
        sub_tasks = from_union([lambda x: from_list(TaskAddonModel.from_dict, x), from_none], obj.get("sub_tasks"))
        return TaskAddonModel(class_name, description, custom_slots, sub_tasks)

    def to_dict(self) -> dict:
        result: dict = {}
        result["class_name"] = from_str(self.class_name)
        result["description"] = from_str(self.description)
        result["custom_slots"] = from_list(from_str, self.custom_slots)
        result["sub_tasks"] = from_union([lambda x: from_list(lambda x: to_class(TaskAddonModel, x), x), from_none], self.sub_tasks)
        return result


def task_addon_model_from_dict(s: Any) -> TaskAddonModel:
    return TaskAddonModel.from_dict(s)


def task_addon_model_to_dict(x: TaskAddonModel) -> Any:
    return to_class(TaskAddonModel, x)
