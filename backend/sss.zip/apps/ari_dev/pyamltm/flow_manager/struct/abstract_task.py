import os
import uuid
from datetime import datetime

from flow_manager.utils.converters import camel_case_to_whites
from flow_manager.utils.decorators import decorate, info
from flow_manager.manifest import Query
from flow_manager.utils.pycore_extensions import S3ManagerExtension


class WorkUnit:
    def __init__(self, flow, task_cfg, lock):
        self.flow = flow
        self.task_wrapper = task_cfg
        self.lock = lock
        self.mark_as_ignored = False
        self.uuid = str(uuid.uuid4())
        self.state = {}
        self.generated_files = []
        self.s3 = S3ManagerExtension('gb', 'dev', 'raw')

    def cached(self):
        return self.task_wrapper.cached

    def flow_cfg(self):
        return self.flow_specs().flow_cfg

    def name(self):
        return "Work Unit " + self.uuid

    def pre_run(self):
        self.update_manifest_on_start()
        return self

    def post_run(self):
        self.update_manifest_on_finish()
        return self

    def log_generated_files(self, indent=0):
        info(f"Generated files : {len(self.generated_files)}",
             indent=indent)
        for tmp in set(self.generated_files):
            info(f' - {tmp.replace(self.output_path(), "")}', indent=indent)

    def update_manifest_on_start(self, parent_uuid=None):
        with self.lock:
            self.state = {
                "uuid": self.uuid,
                "parent": parent_uuid,
                "state": "STARTED",
                "name": self.name(),
                "description": self.task_wrapper.description,
                "start": datetime.now().strftime("%m-%d-%Y %H:%M:%S"),
            }
            self.flow.breakpoints.append(self.state)
            self.flow.manifest.update({
                'state': "PROGRESS",
                'breakpoints': self.flow.breakpoints
            }, Query().uuid == self.flow.uuid)

    def update_manifest_on_finish(self, parent_uuid=None):
        with self.lock:
            self.state.update({
                "state": "SUCCESS",
                "end": datetime.now().strftime("%m-%d-%Y %H:%M:%S"),
            })
            self.flow.breakpoints = self.flow.breakpoints[:-1]
            self.flow.breakpoints.append(self.state)
            self.flow.manifest.update({
                'state': "PROGRESS",
                'breakpoints': self.flow.breakpoints
            }, Query().uuid == self.flow.uuid)

    @decorate(name="Garbage Collection", indent=3)
    def garbage_collection(self):
        return self


class AbstractTask(WorkUnit):
    def __init__(self, task_cfg, flow, lock):
        super().__init__(flow, task_cfg, lock)
        self.sub_tasks = task_cfg.sub_tasks

    def put(self, key, val):
        self.flow.put(key, val)

    def get(self, key):
        return self.flow.get(key)

    def task_cfg(self):
        return self.task_wrapper.task_cfg

    def run(self):
        @decorate(
            name=f"Running task ({camel_case_to_whites(self.task_wrapper.class_name)}/{self.task_wrapper.class_name})",
            indent=3)
        def proto_run(self):
            if len(self.sub_tasks) <= 0:
                return
            from flow_manager.plugins.tasks import subtask_lookup
            self.current_task_wrapper = self.sub_tasks[0]
            while True:
                @decorate(
                    name=f"Starting to run ({camel_case_to_whites(self.current_task_wrapper.class_name)}/{self.current_task_wrapper.class_name})",
                    indent=4)
                def resolve_task(current_wrapper):
                    task = subtask_lookup(current_wrapper)(current_wrapper, self.flow, self, self.lock)
                    task = task.pre_run()
                    if not task.cached():
                        try:
                            task.run()
                        except:
                            task.update_task_state(False)
                    else:
                        info(f"@@@ Skipping ({camel_case_to_whites(current_wrapper.class_name)})", indent=5)
                    task.post_run()

                    return self.next_sub_task(current_wrapper, self.sub_tasks)

                self.current_task_wrapper = resolve_task(self.current_task_wrapper)
                if self.current_task_wrapper is None:
                    break

                info(50 * "#", indent=4)

        proto_run(self)
        return self

    def next_sub_task(self, task, tasks):
        if type(task.slots) == str:
            return self.task_by_marker(task.slots, tasks)
        else:
            for slot in task.slots.custom_slots:
                field = self.flow.data[f'{self.task_wrapper.marker}_{task.marker}_{slot.name}']
                if field:
                    return self.task_by_marker(slot.on_true, tasks)

            field = self.flow.data[f'{self.task_wrapper.marker}_{task.marker}_on_success']
            if field:
                return self.task_by_marker(task.slots.on_success, tasks)
            else:
                return self.task_by_marker(task.slots.on_failure, tasks)

    def task_by_marker(self, marker, tasks):
        for tmp in tasks:
            if tmp.marker == marker:
                return tmp

    @decorate(name="Pre-running task", indent=3)
    def pre_run(self):
        super().pre_run()
        return self

    @decorate(name="Post-running task", indent=3)
    def post_run(self):
        super().post_run()
        self.log_generated_files(indent=4)
        return self


class AbstractNestedTask(WorkUnit):
    def __init__(self, task_cfg, flow, parent_task, lock):
        super().__init__(flow, task_cfg, lock)
        self.parent_task = parent_task
        self.state = {}
        self.sub_tasks = []

    def task_cfg(self):
        return self.parent_task.task_cfg()

    def put(self, key, val):
        self.flow.put(key, val)

    def get(self, key):
        return self.flow.get(key)

    def run(self):
        @decorate(name=f"Running sub-task ({camel_case_to_whites(self.task_wrapper.class_name)})", indent=5)
        def proto_run(self):
            from flow_manager.plugins.tasks import subtask_lookup
            for tmp in self.sub_tasks:
                sub_task = subtask_lookup(tmp)(tmp, self.flow, self, self.lock)
                sub_task.pre_run().run().post_run()

        proto_run(self)
        return self

    @decorate(name="Pre-running task", indent=5)
    def pre_run(self):
        self.update_manifest_on_start(parent_uuid=self.parent_task.uuid)
        return self

    @decorate(name="Post-running task", indent=5)
    def post_run(self):
        self.update_manifest_on_finish(parent_uuid=self.parent_task.uuid)
        self.log_generated_files(indent=6)
        return self
