import os
from concurrent.futures.thread import ThreadPoolExecutor
from flow_manager.manifest import ManifestDB
from flow_manager.struct.abstract_flow import AbstractFlow
from flow_manager.utils.decorators import singleton


@singleton
class CustomThreadPoolExecutor(ThreadPoolExecutor):
    def __init__(self, max_workers=None, lock=None):
        super().__init__(max_workers, thread_name_prefix='CTPE')
        self.lock = lock

    def register_flow(self,flow_specs,**kwargs):
        flow = AbstractFlow().initialize(flow_specs,kwargs)
        #flow.run(self.lock)
        self.submit(flow.run, self.lock)
        return flow.uuid