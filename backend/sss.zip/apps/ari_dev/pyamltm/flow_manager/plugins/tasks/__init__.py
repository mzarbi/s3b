from flow_manager.models.flow_model import Task
import importlib.util, sys
import os

from flow_manager.struct.abstract_task import AbstractTask, AbstractNestedTask
from flow_manager.utils.decorators import error, info

from addons.tasks.startup.task import *
from addons.tasks.startup.sub_tasks import *

from addons.tasks.step0.task import *
from addons.tasks.step0.sub_tasks import *

from addons.tasks.step1.task import *
from addons.tasks.step1.sub_tasks import *

from addons.tasks.step2.task import *
from addons.tasks.step2.sub_tasks import *

from addons.tasks.step3.task import *
from addons.tasks.step3.sub_tasks import *

from addons.tasks.step4.task import *
from addons.tasks.step4.sub_tasks import *

from addons.tasks.step5.task import *
from addons.tasks.step5.sub_tasks import *

from addons.tasks.step6.task import *
from addons.tasks.step6.sub_tasks import *

from addons.tasks.manual_lock.task import *
from addons.tasks.manual_lock.sub_tasks import *

from addons.tasks.rollback.task import *
from addons.tasks.rollback.sub_tasks import *


def load_task_addons():
    task_addons_path = os.path.join(os.environ["ADDONS_PATH"], "addons", "__init__.py")
    spec = importlib.util.spec_from_file_location('tasks', task_addons_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules['tasks'] = module
    spec.loader.exec_module(module)

    #imp.load_source('tasks', task_addons_path)
    info("load_task_addons finished")


def all_subclasses(cls):
    return set(cls.__subclasses__()).union(
        [s for c in cls.__subclasses__() for s in all_subclasses(c)])


def task_lookup(task: Task):
    #load_task_addons()
    info("Looking up")
    info(f'{len(all_subclasses(AbstractTask))} classes')
    for tmp in all_subclasses(AbstractTask):
        if tmp.__name__ == task.class_name:
            return tmp
    error(f"Could not find a task implementation with the following name {task.class_name}")
    return None


def subtask_lookup(task: Task):
    #load_task_addons()
    for tmp in all_subclasses(AbstractNestedTask):
        if tmp.__name__ == task.class_name:
            return tmp
    error(f"Could not find a task implementation with the following name ({task.class_name})")
    return None
