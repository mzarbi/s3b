import os
import sys
import glob
import logging
import datetime

sys.path.append(r'D:\Apps\pycore')
from common.db_access.database import data_bases
from common.parameters import ENV_PARAM, get_external_path

LOG_DIR = r'D:\Data\logs\AMLCM_Data'

s3_project_name = 'core'
core_db_key = '-'.join(['core-data', ENV_PARAM])
core_metadata_db_key = '-'.join(['core-metadata', ENV_PARAM])
core_metadata_db = data_bases[core_metadata_db_key]
PROJECT_NAME = 'AML{}_{}'  # AML Transformation Repository
S3_PROJECT_D = {'CM': 'gb'}

DAILY = 'daily'
MONTHLY = 'monthly'
VERSIONS = ['V3', 'V8']
DATA_TYPES = ['Accounts', 'Alerts', 'AlertsNones', 'AlertsSteps', 'Parameters', 'Parties', 'Payments', 'Postings']
COUNTRIES = ['ARE', 'ARG', 'AUS', 'AUT', 'BGR', 'BHR', 'BRA', 'CHE', 'CHN', 'CZE', 'DEU', 'DNK', 'ESP', 'GBR', 'HKG',
             'HUN', 'IDN', 'IND', 'IRL', 'JPN', 'KOR', 'KWT', 'MYS', 'NLD', 'NOR', 'PRT', 'QAT', 'ROU', 'SAU', 'SGP',
             'SWE', 'THA', 'TWN', 'VNM', 'ZAF']


SHARE_DRIVE = {  # For AML Transformation Data Repository project
    'dev': r'\\nas.euro.net.intra\fr\dev\dfsdatahubcorefr',
    'sit': r'\\nas.euro.net.intra\fr\dev\dfsdatahubcoresitfr',
    'stg': r'\\nas.euro.net.intra\fr\stg\dfsdatahubcorestgfr',
    'prd': r'\\dfs.eu.net.intra\root\CLM\AML\PROD\sh-amlcb-p',
}


def get_file_iso_date(file_name, verbose=False):
    """
    Parses the file name and returns daily or monthly
    example of monthly file: CM_ZAF_TSD_V3_12_DEC_2018.csv ==> 20181201
    example of daily file  : CM_ARE_TSD_V3_20220101.csv ==> 20220101
    :param file_name: base file name:
    :return: iso format date or None
    """
    base_name = os.path.basename(file_name).split('.')[0]
    if verbose:
        logging.info('>>> base_name: {}'.format(base_name))
        logging.info('>>> base_name [-12:-4]: {}'.format(base_name[-8:]))
        logging.info('>>> base_name [-15:-4]: {}'.format(base_name[-11:]))
    try:
        year_date = base_name[-8:]
        datetime.datetime.strptime(year_date, '%Y%m%d')
        return year_date
    except:
        try:
            year_date = base_name[-11:]
            date_time_obj = datetime.datetime.strptime(year_date, '%d_%b_%Y')
            if verbose:
                logging.info('Date:', date_time_obj.replace(day=1).strftime('%Y%m%d'))
            return date_time_obj.replace(day=1).strftime('%Y%m%d')
        except:
            return None
    return None


def initiate_load_control_project(project):
    """
    Insert a new entry in the data base
    :param project: project name
    """
    check_qry = "SELECT COUNT(*) FROM [dbo].[process_load_control_projects] WHERE [project] = '{}'".format(
        project)
    init_qry = "INSERT INTO [dbo].[process_load_control_projects] ([project]) VALUES ('{}')".format(project)
    sql_db = data_bases[core_db_key]
    rows = sql_db.get_row_list_from_query(check_qry)
    if rows[0][0] == 0:
        sql_db.execute_query(init_qry)


def _get_s3_key_from_file_name(perimiter, file_name, country_iso3_code, data_type, version, scenario=None):
    """
    Returns the S3 key to be used to store the file in S3
    example of daily file  : \\dfs.eu.net.intra\root\CLM\AML\PROD\sh-amlcb-p\CM\2021\V3\ZAF\Alerts\TSD\CM_ZAF_TSD_V3_20211024.csv
    example of monthly file: \\dfs.eu.net.intra\root\CLM\AML\PROD\sh-amlcb-p\CM\2021\V3\ZAF\Alerts\TSD\CM_ZAF_TSD_V3_07_JUL_2021.csv
    :param file_path: full file path
    :return: s3 key
    """
    data_date = get_file_iso_date(file_name)
    if not data_date:
        logging.error('>>> file_name with None date: {}'.format(file_name))
        return None

    if scenario:
        s3_key = '/'.join([PROJECT_NAME.format(perimiter, country_iso3_code), data_type,
                           '_'.join([data_type, version, scenario, data_date])])
    else:
        s3_key = '/'.join([PROJECT_NAME.format(perimiter, country_iso3_code), data_type,
                           '_'.join([data_type, version, data_date])])
    return s3_key


def get_files_to_be_ingested(perimeter, year, version='*', country='*', data_type='*', scneario=None, day=None):
    """
    Returns tha list of all files to be ingested (that have not been ingested yet)
    :param perimeter: can be CM, GM or CBK (Cach Management, Global Markets or Correspondent Banking)
    :param year: considered year
    :param version: required version (V3, V8 or * for both)
    :param country: Country ISO3 code
    :param data_type: Accounts, Alerts, AlertsNones, AlertsSteps, Parameters, Parties, Payments or Postings ('' is for all)
    :param scneario: 'EFT', 'FTF', 'TSD' or other ones
    :param day: required day (YYYYMMDD format)
    :return: list of files
    """
    logging.info('get_files_to_be_ingested for year {}'.format(year))

    if scneario:
        folder_path = os.path.join(SHARE_DRIVE[ENV_PARAM], perimeter, str(year), version, country, data_type, scneario)
    else:
        folder_path = os.path.join(SHARE_DRIVE[ENV_PARAM], perimeter, str(year), version, country, data_type)
    logging.info('>> folder_path: {}'.format(folder_path))

    all_folders = glob.glob(folder_path)
    logging.info('>> Nbr of found folders: {}'.format(len(all_folders)))
    final_files = []
    for folder in all_folders:
        all_files = glob.glob(os.path.join(folder, '*'))
        for f in all_files:
            if os.path.getsize(f) > 0:
                final_files.append(f)

    return final_files
