from dotenv import load_dotenv
from flask.cli import FlaskGroup

from server import create_app

load_dotenv()
app = create_app()
cli = FlaskGroup(create_app=create_app)


@cli.command('help')
def help():
    print('help')


@cli.command('purge')
def purge():
    import os
    import shutil

    for root, dirs, files in os.walk(os.environ["CACHE_PATH"]):
        for f in files:
            os.unlink(os.path.join(root, f))
        for d in dirs:
            shutil.rmtree(os.path.join(root, d))


if __name__ == "__main__":
    cli()

