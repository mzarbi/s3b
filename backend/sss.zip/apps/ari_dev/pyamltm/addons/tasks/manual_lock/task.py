from addons import ShortcutMixin, GMM_COMPONENTS, CLUSTERS_NUM
from addons.tasks.manual_lock.commons import plot_clusters
from flow_manager.struct.abstract_task import AbstractTask

from flow_manager.utils.decorators import skippable, info


class ManualLock(AbstractTask, ShortcutMixin):
    """This task will allow the user to perform xxxx"""

    def __init__(self, task_cfg, flow, lock):
        """
        Parameters Serialization Task constructor
        :param task_cfg: Task object (flow_manager.models.flow_model.Task)
        :param flow: AbstractFlow object (flow_manager.struct.abstract_flow.AbstractFlow)
        """
        super().__init__(task_cfg, flow, lock)

    def check_if_best_clusters_defined(self):
        return "GMM_COMPONENTS_RISK_LEVEL" in self.flow_cfg()\
               or \
               "CLUSTERS_NUMBER_RISK_LEVEL" in self.flow_cfg()

    def name(self):
        return 'Manual Lock'

    @skippable()
    def run(self):
        super().run()
        plot_clusters(GMM_COMPONENTS, CLUSTERS_NUM, self.output_path(), self.flow_cfg()["BU"])
        self.update_task_state(self.check_if_best_clusters_defined())

    def update_task_state(self, value):
        self.flow.data[f'{self.task_wrapper.marker}_on_success'] = value
