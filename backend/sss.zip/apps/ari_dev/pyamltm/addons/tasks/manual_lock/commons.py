from base64 import b64encode

import pandas as pd
import os
import matplotlib.pyplot as plt
import json

from addons.tasks.manual_lock.img2b64 import convert_img_files_to_base64_dict


def load_kpis_results(filename):
    df = pd.read_csv(filename, sep=';')
    df['Noise reduction'] = (df['S-B+L1'] + df['S-B+N'] - df['S+B-L1'] - df['S+B-N']) / (
            df['S-B+L1'] + df['S-B+N'] + df['S+B+L1'] + df['S+B+N'])
    df['L2+ Recall'] = (df['S+B+L2+'] / (df['S+B+L2+'] + df['S-B+L2+']))
    df['L3 Recall'] = (df['S+B+L3'] / (df['S+B+L3'] + df['S-B+L3']))
    return df


def plot_clusters(GMM_COMPONENTS, CLUSTERS_NUM, output_path, bu):
    colors = ['blue', 'orange', 'green', 'red', 'magenta', 'olive', 'skyblue', 'gold']
    images = []
    for risk in ['0-LOW', '1-MEDIUM', '2-HIGH', 'ALL']:
        noise_reduction_stats = []
        for gmm in GMM_COMPONENTS:
            for nclusters in CLUSTERS_NUM:
                key = f'run0_cluster_{gmm}_{nclusters}'
                file_kpis = os.path.join(output_path,
                                         bu,
                                         "kpis",
                                         f"hit_kpis_{key}_{risk}_truth.csv")
                if not os.path.exists(file_kpis):
                    continue

                df_kpis = load_kpis_results(file_kpis)
                plt.scatter(
                    [gmm * nclusters],
                    [df_kpis.loc[0, 'Noise reduction']], s=20 * 2 ** (gmm + 1),
                    marker='o', c='None', edgecolors=colors[nclusters - 2]
                )
                noise_reduction_stats.append([gmm, nclusters, gmm * nclusters, df_kpis.loc[0, 'Noise reduction']])

        plt.xlabel('# of clusters')
        plt.title(f"{bu} ({risk})")
        os.makedirs(os.path.join(output_path, bu, "exports", "figures"), exist_ok=True)
        plt.savefig(os.path.join(output_path, bu, "exports", "figures", f"clusters_{bu}_{risk}"), bbox_inches='tight')

        df = pd.DataFrame(noise_reduction_stats,
                          columns=['gmm', 'n_clusters', 'gmm * n_clusters ↑', 'noise reduction ↓'])
        l = df.sort_values(['noise reduction ↓', 'gmm * n_clusters ↑'], ascending=[False, True]).head()

        images.append({
            "img": os.path.join(output_path, bu, "exports", "figures", f"clusters_{bu}_{risk}.png"),
            "data": l.values.tolist()
        })

    dc = convert_img_files_to_base64_dict(images)

    with open(os.path.join(output_path, bu, "exports", "figures", f"clusters_map.json"), "w") as f:
        json.dump(dc, f, indent=4, separators=(',', ': '), cls=Base64Encoder)


class Base64Encoder(json.JSONEncoder):
    # pylint: disable=method-hidden
    def default(self, o):
        if isinstance(o, bytes):
            return b64encode(o).decode()
        return json.JSONEncoder.default(self, o)
