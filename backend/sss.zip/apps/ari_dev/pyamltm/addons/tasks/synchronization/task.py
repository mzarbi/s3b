from addons.tasks.commons.task_utils import ShortcutMixin
from flow_manager.struct.abstract_task import AbstractTask
from flow_manager.utils.decorators import skippable


class Synchronization(AbstractTask, ShortcutMixin):
    """This task will allow the user to perform xxxx"""

    def __init__(self, task_cfg, flow, lock):
        """
        Startup Task constructor
        :param task_cfg: Task object (flow_manager.models.flow_model.Task)
        :param flow: AbstractFlow object (flow_manager.struct.abstract_flow.AbstractFlow)
        """
        super().__init__(task_cfg, flow, lock)

    def name(self):
        return 'Synchronization'

    @skippable()
    def run(self):
        pass