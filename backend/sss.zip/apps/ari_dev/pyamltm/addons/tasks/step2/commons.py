GMM_COMPONENTS = range(1, 5)
CLUSTERS_NUM = range(1, 9)