from addons import ShortcutMixin
from flow_manager.struct.abstract_task import AbstractTask
from addons.tasks.commons.aml_transaction_monitoring import run_pipeline, Parameters
from flow_manager.utils.decorators import skippable


class Step1(AbstractTask, ShortcutMixin):
    """This task will allow the user to perform xxxx"""

    def __init__(self, task_cfg, flow, lock):
        """
        Parameters Serialization Task constructor
        :param task_cfg: Task object (flow_manager.models.flow_model.Task)
        :param flow: AbstractFlow object (flow_manager.struct.abstract_flow.AbstractFlow)
        """
        super().__init__(task_cfg, flow, lock)

    def name(self):
        return 'Feature Engineering'

    @skippable()
    def run(self):
        super().run()
        params = Parameters.from_dict(self.flow_cfg(), self.task_cfg())
        run_pipeline(params)

    def update_task_state(self, value):
        self.flow.data[f'{self.task_wrapper.marker}_on_success'] = value
