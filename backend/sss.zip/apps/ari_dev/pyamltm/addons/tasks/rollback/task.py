import shutil

from addons import ShortcutMixin
from addons.tasks.commons.aml_transaction_monitoring.utils import constants
from flow_manager.struct.abstract_task import AbstractTask

from flow_manager.utils.decorators import skippable, info


class Rollback(AbstractTask, ShortcutMixin):
    """This task will allow the user to perform xxxx"""

    def __init__(self, task_cfg, flow, lock):
        """
        Parameters Serialization Task constructor
        :param task_cfg: Task object (flow_manager.models.flow_model.Task)
        :param flow: AbstractFlow object (flow_manager.struct.abstract_flow.AbstractFlow)
        """
        super().__init__(task_cfg, flow, lock)
        if self.task_cfg()["DELETE_INPUT_CACHE"]:
            shutil.rmtree(constants.READ_ONLY_DATA_PATH())
        if self.task_cfg()["DELETE_KYC_CACHE"]:
            shutil.rmtree(constants.KYC_DATA_PATH())
        if self.task_cfg()["DELETE_OUTPUT_CACHE"]:
            shutil.rmtree(constants.READ_WRITE_DATA_PATH())

    def name(self):
        return 'Rollback'

    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_wrapper.marker}_on_success'] = value
