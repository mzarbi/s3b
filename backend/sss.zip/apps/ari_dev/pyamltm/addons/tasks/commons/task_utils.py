import os


class ShortcutMixin:
    def flow_specs(self):
        return self.flow.specs()

    def env(self):
        return self.flow.flow_cfg.env

    def resources_path(self):
        return self.env().RESOURCES_PATH

    def cache_path(self):
        return self.env().CACHE_PATH

    def flow_cache_path(self):
        return os.path.join(self.cache_path(), self.flow_uuid())

    def flow_uuid(self):
        if os.environ["LOCAL_RUN"] == "True":
            return self.flow.flow_cfg.specs.flow_cfg["UUID"]
        else:
            return self.flow.uuid


    def input_path(self):
        return self.flow.data["INPUT_PATH"]

    def output_path(self):
        return self.flow.data["OUTPUT_PATH"]

    def kyc_path(self):
        return self.flow.data["KYC_PATH"]

    def other_resources_path(self):
        return self.flow.data["OTHER_RESOURCES_PATH"]

    def task_cfg(self):
        return self.task_wrapper.task_cfg
