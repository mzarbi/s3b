import filecmp
import os
import pickle
import shutil
import pandas as pd
import numpy as np
from tqdm import tqdm
import warnings

warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')


def copy_file(src, dst):
    shutil.copy(src, dst)


def copy_files(src, dst, recursively=False):
    if type(src) == list:
        for tmp in src:
            copy_file(tmp, dst)
    elif type(src) == str:
        for tmp in list_all_files_in_dir(src, recursively):
            copy_file(tmp, dst)


def save_as_pickle(obj, filename):
    '''Saves obj as pickle'''
    with open(filename, 'wb') as f:
        pickle.dump(obj, f)


def load_pickle_file(filename):
    '''Load any pickle file'''
    with open(filename, 'rb') as f:
        return pickle.load(f)


def compare_file_sizes(p1, p2):
    return os.stat(p1).st_size == os.stat(p2).st_size


def compare_xlsx(p1, p2):
    if not compare_file_sizes(p1, p2):
        return False

    template = pd.read_excel(p1, na_values=np.nan, header=None)
    testSheet = pd.read_excel(p2, na_values=np.nan, header=None)

    rt, ct = template.shape
    rtest, ctest = testSheet.shape

    df = pd.DataFrame(columns=['Cell_Location', 'BaseTemplate_Value', 'CurrentFile_Value'])

    for rowNo in range(max(rt, rtest)):
        for colNo in range(max(ct, ctest)):
            # Fetching the template value at a cell
            try:
                template_val = template.iloc[rowNo, colNo]
            except:
                template_val = np.nan

            # Fetching the testsheet value at a cell
            try:
                testSheet_val = testSheet.iloc[rowNo, colNo]
            except:
                testSheet_val = np.nan

            # Comparing the values
            if str(template_val) != str(testSheet_val):
                return False
    return True


def unique_excel_files_in_dir(dir_path, recursively=False, extension="", cmp_func=filecmp.cmp,
                                       name_contains=""):
    return unique_files_in_dir(dir_path, recursively, extension, cmp_func=compare_xlsx,
                                        name_contains=name_contains)


def unique_files_in_dir(dir_path, recursively=False, extension="", cmp_func=filecmp.cmp, name_contains=""):
    ls = list_all_files_in_dir(dir_path, recursively, extension, name_contains)
    vc = [{
        "name": f,
        "size": os.stat(f).st_size
    } for f in ls]
    uq = []
    uqfz = list(set([f["size"] for f in vc]))
    for tmp in tqdm(uqfz, desc="Comparing file clusters"):
        vc_ = [f for f in vc if f["size"] == tmp]
        uq_ = [vc_[0]["name"]]
        uq.append(vc_[0]["name"])
        for i in range(1, len(vc_)):
            for tmp2 in uq_:
                if not cmp_func(vc_[i]["name"], tmp2):
                    uq_.append(vc_[i]["name"])
                    uq.append(vc_[i]["name"])
    return uq


def list_all_files_in_dir(dir_path, recursively=False, extension="", name_contains=""):
    ls = []
    if recursively:
        for root, dirs, files in os.walk(dir_path):
            for file in files:
                if extension == "":
                    if name_contains == "":
                        ls.append(os.path.join(root, file))
                    else:
                        if file.__contains__(name_contains):
                            ls.append(os.path.join(root, file))
                else:
                    if file.__contains__(extension) or extension == "":
                        if name_contains == "":
                            ls.append(os.path.join(root, file))
                        else:
                            if file.__contains__(name_contains):
                                ls.append(os.path.join(root, file))
    else:
        for file in os.listdir(dir_path):
            if os.path.isfile(os.path.join(dir_path, file)):
                if extension == "":
                    if name_contains == "":
                        ls.append(file)
                    else:
                        if file.__contains__(name_contains):
                            ls.append(file)
                else:
                    if file.__contains__(extension) or extension == "":
                        if name_contains == "":
                            ls.append(file)
                        else:
                            if file.__contains__(name_contains):
                                ls.append(file)
    return ls
