import json
import os

from datetime import datetime

from addons.tasks.commons.aml_transaction_monitoring.utils import constants
from addons.tasks.commons.file_system import list_all_files_in_dir, copy_files, copy_file
from addons.tasks.commons.task_utils import ShortcutMixin
from addons.tasks.startup.commons import parse_monthly_filenames, parse_daily_filenames
from flow_manager.models.flow_model import flow_model_to_dict
from flow_manager.struct.abstract_task import AbstractTask
from flow_manager.utils.decorators import skippable, decorate, info, error, warn
from tqdm import tqdm


class Startup(AbstractTask, ShortcutMixin):
    """This task will allow the user to perform xxxx"""

    def __init__(self, task_cfg, flow, lock):
        """
        Startup Task constructor
        :param task_cfg: Task object (flow_manager.models.flow_model.Task)
        :param flow: AbstractFlow object (flow_manager.struct.abstract_flow.AbstractFlow)
        """
        super().__init__(task_cfg, flow, lock)
        self.files_to_download = {}
        self.data_valid = False

    def name(self):
        return 'Startup'

    @skippable()
    def run(self):
        self.create_cache_folder()
        self.store_flow_specs()
        self.convert_flow_specs()
        info(f"Task id : {self.flow_uuid()}", indent=3)
        download_files = self.task_cfg()["DOWNLOAD_FILES"]
        if download_files:
            self.resolving_required_files()
            self.download_data()
        else:
            info(f"@@Skipping file download", indent=3)
        self.replace_uploaded_files()
        self.validate_data()

    @decorate(name="Convert Flow Specs", indent=4)
    def convert_flow_specs(self):
        self.flow_cfg()["LOCAL_CURRENCY_RATE"] = float(self.flow_cfg()["LOCAL_CURRENCY_RATE"])

    @decorate(name="Store Flow Specs", indent=4)
    def store_flow_specs(self):
        with open(os.path.join(self.flow_cache_path(), "flow.json"), "w") as f:
            json.dump(flow_model_to_dict(self.flow.flow_specs), f)

    @decorate(name="Validate data", indent=4)
    def validate_data(self):
        self.data_valid = self.validate_parameters()
        self.data_valid &= self.validate_payments()
        self.data_valid &= self.validate_postings()

        if self.data_valid:
            self.update_task_state(True)
        else:
            self.update_task_state(False)

    def validate_postings(self):
        return True

    def validate_payments(self):
        return True

    def validate_parameters(self):
        return True

    @decorate(name="Resolving KYC data", indent=5)
    def resolving_kyc_files(self):
        self.files_to_download = {
            "KYC": {
                "gcars_report.csv": self.resolve_gcars_report(self.flow_cfg()["KYC"]["GCARS_REPORT"]),
                "country_risk.csv": self.resolve_country_risk(self.flow_cfg()["KYC"]["COUNTRY_RISK_REPORT"]),
                "sensitivity_report.csv": self.resolve_sensitivity_report(self.flow_cfg()["KYC"]["SENSITIVITY_REPORT"]),
                "kyc_reliance_worldwide.csv": self.resolve_kyc_reliance_worldwide(
                    self.flow_cfg()["KYC"]["KYC_RELIANCE_WORLDWIDE_REPORT"])
            }
        }

    @decorate(name="Resolving Alerts data", indent=5)
    def resolving_alert_files(self, start_date, end_date):
        start_year = start_date.year
        end_year = end_date.year

        def filtering_monthly_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_monthly_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.files_to_download["ALERTS"] = {}

        SAM3_MODELS = ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP", "EFT", "FTF", "TSD"]
        SAM8_MODELS = ["ADR", "CTF", "EPC", "KHI", "KLO", "LTH", "NBI", "SBP", "STP", "THV", "EFT", "FTF", "TSD"]
        models = list(set(SAM3_MODELS + SAM8_MODELS))
        for year in range(start_year, end_year + 1):
            self.files_to_download["ALERTS"][year] = {}
            for tmp in models:
                self.files_to_download["ALERTS"][year][tmp] = {}
                info(f"Resolving {tmp} ({year})", indent=6)

                files = self.s3.list_s3_files(f"AMLCM_{self.flow_cfg()['BU']}/{year}/Alerts/{tmp}/")

                if files is None:
                    files = []

                files = [f for f in files if not f["Key"].endswith("/")]
                info(f"Files found {tmp} ({year}) : {len(files)}", indent=7)
                files = filtering_monthly_files(files, start_date, end_date)
                info(f"Files in range {tmp} ({year}) : {len(files)}", indent=7)

                for file in files:
                    self.files_to_download["ALERTS"][year][tmp].update({
                        file["Key"].split("/")[-1]: self.resolve_alert(
                            self.flow_cfg()['BU'], year, tmp, file["Key"].split("/")[-1]
                        )
                    })

    @decorate(name="Resolving IT Alerts data", indent=5)
    def resolving_it_alert_files(self, start_date, end_date):
        start_year = start_date.year
        end_year = end_date.year

        def filtering_monthly_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_monthly_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.files_to_download["IT_ALERTS"] = {}

        SAM3_MODELS = ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP", "EFT", "FTF", "TSD"]
        SAM8_MODELS = ["ADR", "CTF", "EPC", "KHI", "KLO", "LTH", "NBI", "SBP", "STP", "THV", "EFT", "FTF", "TSD"]
        models = list(set(SAM3_MODELS + SAM8_MODELS))

        for year in range(start_year, end_year + 1):
            self.files_to_download["IT_ALERTS"][year] = {}
            for tmp in models:
                self.files_to_download["IT_ALERTS"][year][tmp] = {}
                info(f"Resolving {tmp} ({year})", indent=6)

                files = self.s3.list_s3_files(
                    f"AMLCM_{self.flow_cfg()['BU']}/{year}/Alerts_run0/{tmp}/"
                )

                if files is None:
                    files = []

                files = [f for f in files if not f["Key"].endswith("/")]
                info(f"Files found {tmp} ({year}) : {len(files)}", indent=7)
                files = filtering_monthly_files(files, start_date, end_date)
                info(f"Files in range {tmp} ({year}) : {len(files)}", indent=7)

                for file in files:
                    self.files_to_download["IT_ALERTS"][year][tmp].update({
                        file["Key"].split("/")[-1]: self.resolve_it_alert(
                            self.flow_cfg()['BU'], year, tmp, file["Key"].split("/")[-1]
                        )
                    })

    def resolving_data_files(self, key, folder, start_date, end_date, filter=None):
        start_year = start_date.year
        end_year = end_date.year

        self.files_to_download[key] = {}
        for year in range(start_year, end_year + 1):
            self.files_to_download[key][year] = {}
            files = self.s3.list_s3_files(f"AMLCM_{self.flow_cfg()['BU']}/{year}/{folder}/")
            if files is None:
                files = []

            files = [f for f in files if not f["Key"].endswith("/")]
            info(f"Files found ({year}) : {len(files)}", indent=7)
            if filter is not None:
                files = filter(files, start_date, end_date)
            info(f"Files in range ({year}) : {len(files)}", indent=7)

            for file in files:
                fname = file["Key"].split("/")[-1]
                self.files_to_download[key][year].update({
                    file["Key"].split("/")[-1]: f"AMLCM_{self.flow_cfg()['BU']}/{year}/{folder}/{fname}"
                })

    @decorate(name="Resolving Alert Notes data", indent=5)
    def resolving_alert_notes_files(self, start_date, end_date):
        def filtering_monthly_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_monthly_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.resolving_data_files("ALERT_NOTES", "AlertsNotes", start_date, end_date, filter=filtering_monthly_files)

    @decorate(name="Resolving Alert Steps data", indent=5)
    def resolving_alert_steps_files(self, start_date, end_date):
        def filtering_monthly_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_monthly_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.resolving_data_files("ALERT_STEPS", "AlertsSteps", start_date, end_date, filter=filtering_monthly_files)

    @decorate(name="Resolving Payments data", indent=5)
    def resolving_payments(self, start_date, end_date):
        def filtering_monthly_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_monthly_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.resolving_data_files("PAYMENTS", "Payments", start_date, end_date, filter=filtering_monthly_files)

    @decorate(name="Resolving Payments data", indent=5)
    def resolving_postings(self, start_date, end_date):
        def filtering_monthly_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_monthly_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.resolving_data_files("POSTINGS", "Postings", start_date, end_date, filter=filtering_monthly_files)

    @decorate(name="Resolving Accounts data", indent=5)
    def resolving_accounts(self, start_date, end_date):
        def filtering_monthly_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_monthly_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.resolving_data_files("ACCOUNTS", "Accounts", start_date, end_date, filter=filtering_monthly_files)

    @decorate(name="Resolving Buckets data", indent=5)
    def resolving_buckets(self, start_date, end_date):
        self.resolving_data_files("BUCKETS", "Buckets", start_date, end_date)

    @decorate(name="Resolving Parties data", indent=5)
    def resolving_parties(self, start_date, end_date):
        def filtering_monthly_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_monthly_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.resolving_data_files("PARTIES", "Parties", start_date, end_date, filter=filtering_monthly_files)

    @decorate(name="Resolving Threshold Parameters data", indent=5)
    def resolving_threshold_parameters(self, start_date, end_date):
        def filtering_daily_files(files, start_date, end_date):
            if len(files) == 1:
                warn(f"A single file was found in this folder", indent=7)
                return files
            files_ = []
            for i, file in enumerate(files):
                try:
                    date = parse_daily_filenames(file["Key"].split("/")[-1])
                    if (date >= start_date and date <= end_date):
                        files_.append(files[i])
                except:
                    error(f"Could not parse filename : {file['Key'].split('/')[-1]}", indent=7)
            return files_

        self.resolving_data_files(
            "PARAMETERS",
            "Parameters",
            start_date,
            end_date,
            filter=filtering_daily_files
        )

    @decorate(name="Resolving Other Resources data", indent=5)
    def resolving_other_resources(self):
        self.files_to_download["OTHERS"] = {
            "parameters_template.xlsx": "AMLCM/parameters_template.xlsx"
        }

    @decorate(name="Resolving required files", indent=4)
    def resolving_required_files(self):
        #self.flow_cfg()['BU'] = "BGR"

        self.resolving_kyc_files()

        date_format = '%Y-%m-%d'
        start_date = datetime.strptime(
            self.flow_cfg()["ANALYSIS_DATES"]["DATA"]["FROM"],
            date_format
        )
        end_date = datetime.strptime(
            self.flow_cfg()["ANALYSIS_DATES"]["DATA"]["TO"],
            date_format
        )

        self.resolving_alert_files(start_date, end_date)
        self.resolving_it_alert_files(start_date, end_date)
        self.resolving_alert_notes_files(start_date, end_date)
        self.resolving_alert_steps_files(start_date, end_date)
        self.resolving_payments(start_date, end_date)
        self.resolving_postings(start_date, end_date)
        self.resolving_parties(start_date, end_date)
        self.resolving_buckets(start_date, end_date)
        self.resolving_accounts(start_date, end_date)
        self.resolving_threshold_parameters(start_date, end_date)
        self.resolving_other_resources()

    def resolve_alert(self, business_unit, year, model, key):
        return f"AMLCM_{business_unit}/{year}/Alerts/{model}/{key}"

    def resolve_it_alert(self, business_unit, year, model, key):
        return f"AMLCM_{business_unit}/{year}/Alerts_run0/{model}/{key}"

    def resolve_kyc(self, type, gc, default):
        if gc == '':
            info(f"Using default file ({type})", indent=5)
            return f"AMLCM/KYC/{type}/{default}.csv"
        if self.s3.is_file(f"AMLCM/KYC/{type}/" + gc):
            info(f"Using file : {gc} ({type})", indent=5)
            return f"AMLCM/KYC/{type}/" + gc
        info(f"Using default file ({type})", indent=5)
        return f"AMLCM/KYC/{type}/{default}.csv"

    def resolve_gcars_report(self, gc):
        return self.resolve_kyc("GCARS_REPORTS", gc, "gcars_report")

    def resolve_country_risk(self, gc):
        return self.resolve_kyc("COUNTRY_RISKS", gc, "country_risk")

    def resolve_kyc_reliance_worldwide(self, gc):
        return self.resolve_kyc("KYC_RELIANCE_WORLDWIDE", gc, "kyc_reliance_worldwide")

    def resolve_sensitivity_report(self, gc):
        return self.resolve_kyc("SENSITIVITY_REPORTS", gc, "sensitivity_report")

    @decorate(name="Download KYC data", indent=5)
    def download_kyc(self):
        for tmp in tqdm(self.files_to_download["KYC"], desc="Downloading KYC"):
            os.makedirs(os.path.join(self.input_path(),"kyc"),exist_ok=True)
            self.s3.download_file(
                self.files_to_download["KYC"][tmp],
                file_path=os.path.join(self.input_path(),"kyc", tmp)
            )

    @decorate(name="Download Alerts data", indent=5)
    def download_alerts(self):
        for year in self.files_to_download["ALERTS"]:
            info(f"Downloading ALERTS / {year}", indent=6)
            for model in self.files_to_download["ALERTS"][year]:
                info(f"Downloading ALERTS / {year} / {model}", indent=7)
                os.makedirs(os.path.join(
                    self.input_path(),
                    str(year),
                    "V3",
                    self.flow_cfg()['BU'],
                    "Alerts",
                    model,
                ),exist_ok=True)
                for ff in tqdm(self.files_to_download["ALERTS"][year][model],
                               desc=f"Downloading Alert ({year}) / ({model})"):
                    self.s3.download_file(
                        self.files_to_download["ALERTS"][year][model][ff],
                        file_path=os.path.join(
                            self.input_path(),
                            str(year),
                            "V3",
                            self.flow_cfg()['BU'],
                            "Alerts",
                            model,
                            ff
                        )
                    )

    @decorate(name="Download IT Alerts data", indent=5)
    def download_it_alerts(self):
        for year in self.files_to_download["IT_ALERTS"]:
            info(f"Downloading IT_ALERTS / {year}", indent=6)
            for model in self.files_to_download["IT_ALERTS"][year]:
                info(f"Downloading IT_ALERTS / {year} / {model}", indent=7)
                os.makedirs(os.path.join(
                    self.input_path(),
                    str(year),
                    "V8",
                    self.flow_cfg()['BU'],
                    "Alerts_run0",
                    model,
                ), exist_ok=True)
                for ff in tqdm(self.files_to_download["IT_ALERTS"][year][model],
                               desc=f"Downloading IT_ALERTS ({year}) / ({model})"):

                    self.s3.download_file(
                        self.files_to_download["IT_ALERTS"][year][model][ff],
                        file_path=os.path.join(
                            self.input_path(),
                            str(year),
                            "V8",
                            self.flow_cfg()['BU'],
                            "Alerts_run0",
                            model,
                            ff
                        )
                    )

    @decorate(name="Download Alert Steps data", indent=5)
    def download_alert_steps(self):
        for year in self.files_to_download["ALERT_STEPS"]:
            os.makedirs(
                os.path.join(self.input_path(), str(year), "V3", self.flow_cfg()['BU'], "AlertsSteps")
            ,exist_ok=True)
            for ff in tqdm(self.files_to_download["ALERT_STEPS"][year], desc=f"Downloading Alert Steps ({year})"):
                self.s3.download_file(
                    self.files_to_download["ALERT_STEPS"][year][ff],
                    file_path=os.path.join(self.input_path(), str(year), "V3", self.flow_cfg()['BU'], "AlertsSteps", ff)
                )

    @decorate(name="Download Alert Notes data", indent=5)
    def download_alert_notes(self):
        for year in self.files_to_download["ALERT_NOTES"]:
            os.makedirs(
                os.path.join(self.input_path(), str(year), "V3", self.flow_cfg()['BU'], "AlertsNotes")
            ,exist_ok=True)
            for ff in tqdm(self.files_to_download["ALERT_NOTES"][year], desc=f"Downloading Alert Notes ({year})"):
                self.s3.download_file(
                    self.files_to_download["ALERT_NOTES"][year][ff],
                    file_path=os.path.join(self.input_path(), str(year), "V3", self.flow_cfg()['BU'], "AlertsNotes", ff)
                )

    @decorate(name="Download Payments data", indent=5)
    def download_payments(self):
        for year in self.files_to_download["PAYMENTS"]:
            os.makedirs(
                os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Payments")
            ,exist_ok=True)
            for ff in tqdm(self.files_to_download["PAYMENTS"][year], desc=f"Downloading Payments ({year})"):
                self.s3.download_file(
                    self.files_to_download["PAYMENTS"][year][ff],
                    file_path=os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Payments", ff)
                )

    @decorate(name="Download Postings data", indent=5)
    def download_postings(self):
        for year in self.files_to_download["POSTINGS"]:
            os.makedirs(
                os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Postings")
            ,exist_ok=True)
            for ff in tqdm(self.files_to_download["POSTINGS"][year], desc=f"Downloading Postings ({year})"):
                self.s3.download_file(
                    self.files_to_download["POSTINGS"][year][ff],
                    file_path=os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Postings", ff)
                )

    @decorate(name="Download Threshold Parameters data", indent=5)
    def download_threshold_parameters(self):
        for year in self.files_to_download["PARAMETERS"]:
            os.makedirs(
                os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Parameters")
            ,exist_ok=True)
            for ff in tqdm(self.files_to_download["PARAMETERS"][year], desc=f"Downloading Parameters ({year})"):
                self.s3.download_file(
                    self.files_to_download["PARAMETERS"][year][ff],
                    file_path=os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Parameters", ff)
                )

    @decorate(name="Download Buckets data", indent=5)
    def download_buckets(self):
        for year in tqdm(self.files_to_download["BUCKETS"], desc="Downloading Buckets"):
            os.makedirs(
                os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Buckets")
            ,exist_ok=True)
            for ff in self.files_to_download["BUCKETS"][year]:
                self.s3.download_file(
                    self.files_to_download["BUCKETS"][year][ff],
                    file_path=os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Buckets", ff)
                )

    @decorate(name="Download Accounts data", indent=5)
    def download_accounts(self):
        for year in tqdm(self.files_to_download["ACCOUNTS"], desc="Downloading Accounts"):
            os.makedirs(
                os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Accounts")
            ,exist_ok=True)
            for ff in self.files_to_download["ACCOUNTS"][year]:
                self.s3.download_file(
                    self.files_to_download["ACCOUNTS"][year][ff],
                    file_path=os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Accounts", ff)
                )

    @decorate(name="Download Parties data", indent=5)
    def download_parties(self):
        for year in tqdm(self.files_to_download["PARTIES"], desc="Downloading Parties"):
            os.makedirs(
                os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Parties")
            ,exist_ok=True)
            for ff in self.files_to_download["PARTIES"][year]:
                self.s3.download_file(
                    self.files_to_download["PARTIES"][year][ff],
                    file_path=os.path.join(self.input_path(), str(year), "V8", self.flow_cfg()['BU'], "Parties", ff)
                )

    @decorate(name="Download Other Resources data", indent=5)
    def download_other_resources(self):
        os.makedirs(os.path.join(
            self.input_path(), "other_resources"
        ),exist_ok=True)
        self.s3.download_file(
            "AMLCM/parameters_template.xlsx",
            file_path=os.path.join(
                self.input_path(), "other_resources", "parameters_template.xlsx"
            )
        )

    @decorate(name="Download data", indent=4)
    def download_data(self):
        self.download_kyc()
        self.download_alerts()
        self.download_it_alerts()
        self.download_alert_steps()
        self.download_alert_notes()
        self.download_accounts()
        self.download_buckets()
        self.download_parties()
        self.download_payments()
        self.download_postings()
        self.download_threshold_parameters()
        self.download_other_resources()

    def replace_uploaded_files(self):
        f = self.flow.kwargs().get("buckets_file", None)
        if f is not None:
            for root, dirs, files in os.walk(self.input_path()):
                for name in dirs:
                    if name == "Buckets":
                        f.save(os.path.join(root, name, f.filename))

        f = self.flow.kwargs().get("threshold_parameters_file", None)
        if f is not None:
            for root, dirs, files in os.walk(self.input_path()):
                for name in dirs:
                    if name == "Parameters":
                        f.save(os.path.join(root, name, f.filename))

    def copy_files(self):
        make_copies = self.task_cfg()["DOWNLOAD_FILES"]
        rep = r"C:\Users\e63551\Desktop\INPUT"
        ls = list_all_files_in_dir(rep, recursively=True)
        if make_copies:
            for tmp in (pbar := tqdm(ls, desc="Copying files")):
                pbar.set_description("Copying files from %s" % tmp.replace(rep, ""))
                os.makedirs(os.path.dirname(
                    os.path.join(constants.READ_ONLY_DATA_PATH(), tmp.replace(rep, "")[1:])),
                    exist_ok=True
                )
                copy_file(
                    tmp,
                    os.path.join(constants.READ_ONLY_DATA_PATH(), tmp.replace(rep, "")[1:])
                )

        rep = r"C:\Users\e63551\Desktop\INPUT\kyc"
        ls = list_all_files_in_dir(rep, recursively=True)
        if make_copies:
            for tmp in (pbar := tqdm(ls, desc="Copying files")):
                pbar.set_description("Copying files from %s" % tmp.replace(rep, ""))
                os.makedirs(os.path.dirname(
                    os.path.join(constants.KYC_DATA_PATH(), tmp.replace(rep, "")[1:])),
                    exist_ok=True
                )
                copy_file(
                    tmp,
                    os.path.join(constants.KYC_DATA_PATH(), tmp.replace(rep, "")[1:])
                )

    @decorate(name="Create cache folder", indent=4)
    def create_cache_folder(self):

        constants.UUID = self.flow_uuid()

        os.makedirs(self.flow_cache_path(), exist_ok=True)
        self.flow.put("INPUT_PATH", os.path.join(self.flow_cache_path(), "INPUT"))
        os.makedirs(os.path.join(self.flow_cache_path(), "INPUT"), exist_ok=True)

        self.flow.put("OUTPUT_PATH", os.path.join(self.flow_cache_path(), "OUTPUT"))
        os.makedirs(os.path.join(self.flow_cache_path(), "OUTPUT"), exist_ok=True)

        self.flow.put("KYC_PATH", os.path.join(self.flow_cache_path(), "KYC"))
        os.makedirs(os.path.join(self.flow_cache_path(), "KYC"), exist_ok=True)

        self.flow.put("OTHER_RESOURCES_PATH", os.path.join(self.flow_cache_path(), "OTHER_RESOURCES"))
        os.makedirs(os.path.join(self.flow_cache_path(), "OTHER_RESOURCES"), exist_ok=True)

    def update_task_state(self, value):
        self.flow.data[f'{self.task_wrapper.marker}_on_success'] = value
