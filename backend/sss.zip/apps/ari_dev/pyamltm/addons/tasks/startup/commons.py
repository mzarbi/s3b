import os
from datetime import datetime


def create_cache_folder(path):
    os.makedirs(path, exist_ok=True)
    os.makedirs(os.path.join(path, "INPUT"), exist_ok=True)
    for i in ["Alerts", "Alerts Notes", "Alerts Steps", "Other files", "Payments", "Postings"]:
        os.makedirs(os.path.join(path, "INPUT"), exist_ok=True)

    os.makedirs(os.path.join(path, "OUTPUT"), exist_ok=True)
    os.makedirs(os.path.join(path, "KYC"), exist_ok=True)

def parse_monthly_filenames(s):
    return datetime.strptime(s.split(".")[-2][-11:], '%d_%b_%Y')


def parse_daily_filenames(s):
    return datetime.strptime(s.split(".")[-2][-8:], '%Y%m%d')