import os

from flask import render_template, Blueprint, make_response, send_from_directory, request

client_blueprint = Blueprint("main", __name__, )


@client_blueprint.route('/')
@client_blueprint.route('/amltm/')
@client_blueprint.route('/amltm/dashboard')
@client_blueprint.route('/amltm/flow-explorer')
@client_blueprint.route('/amltm/archive-explorer')
@client_blueprint.route('/amltm/new-flow')
@client_blueprint.route('/amltm/flows')
def index():
    theurl = '/amltm/'
    return render_template('index.html', base_url=theurl)


@client_blueprint.route('/amltm/flows/<path:path>')
def flows(path):
    if request.path.split('/') == '/':
        theurl = '/'
    else:
        theurl = '/amltm/'
    return render_template('index.html', base_url=theurl)


@client_blueprint.route('/<path:path>')
@client_blueprint.route('/amltm/<path:path>')
def static_asset(path):
    path = str(path)
    full_path = client_blueprint.root_path.replace('server\client', '')
    full_path = os.path.join(full_path, 'frontend', 'dist')
    return send_from_directory(full_path, path)
