import json
import os


def flow_specs_from_uuid(uuid):
    with open(os.path.join(os.environ["CACHE_PATH"], uuid, "flow.json"), "r") as f:
        return json.load(f)

def getLogs(path):
    try:
        with open(path,"r") as f:
            return f.read()
    except:
        return "Logs not available"

def path_to_dict(path, origin):
    d = {'label': os.path.basename(path), "absolute_url": path.replace(origin, "")[1:]}
    if os.path.isdir(path):
        d['type'] = "directory"
        d['nodes'] = [path_to_dict(os.path.join(path, x), origin) for x in os.listdir(path)]
    else:
        d['type'] = "file"
    return d


def build_flow(dc):
    return {
        "name": dc["flow"]["NAME"],
        "maintainer": {
            "name": "Mohamed Zied El Arbi",
            "email": "medzied.arbi@gmail.com"
        },
        "flow_cfg": dc["flow"],
        "entry_point": "Startup",
        "tasks": [
            {
                "marker": "Startup",
                "class_name": "Startup",
                "description": "This task will allow the user to perform xxxx",
                "cached": False,
                "task_cfg": {
                    "DOWNLOAD_FILES": dc["startup"]["flow_startup_download_files"]
                },
                "sub_tasks": [],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "Step0",
                    "on_failure": "Rollback"
                }
            },
            {
                "marker": "Step0",
                "class_name": "Step0",
                "description": "This task will allow the user to perform xxxx",
                "cached": dc["step0"]["flow_step0_skip"],
                "task_cfg": {
                    "EXPERIMENT_KEY": dc["step0"]["flow_step0_experiment_key"],
                    "PIPELINE_STEPS": {
                        "PARAMETERS_SERIALIZATION": {
                            "PARAMETERS": dc["step0"]["flow_step0_pipeline_steps_parameters_serialization_parameters"]
                        },
                        "DATA_SERIALIZATION": {
                            "ALERTS_SERIALISATION": dc["step0"][
                                "flow_step0_pipeline_steps_data_serialization_alerts_serialisation"],
                            "TRANSACTIONS_SERIALISATION": dc["step0"][
                                "flow_step0_pipeline_steps_data_serialization_transactions_serialisation"],
                            "AMLIT_ALERTS_SERIALISATION": dc["step0"][
                                "flow_step0_pipeline_steps_data_serialization_amlit_alerts_serialisation"],
                            "LOOKBACK_SUMS": dc["step0"]["flow_step0_pipeline_steps_data_serialization_lookback_sums"]
                        }
                    }
                },
                "sub_tasks": [],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "Step1",
                    "on_failure": "Rollback"
                }
            },
            {
                "marker": "Step1",
                "class_name": "Step1",
                "description": "This task will allow the user to perform xxxx",
                "cached": dc["step1"]["flow_step1_skip"],
                "task_cfg": {
                    "EXPERIMENT_KEY": dc["step1"]["flow_step1_experiment_key"],
                    "PIPELINE_STEPS": {
                        "CLUSTERING_FEATURES": {
                            "TRANSACTIONS": dc["step1"]["flow_step1_pipeline_steps_clustering_features_transactions"],
                            "PARAMETERS": dc["step1"]["flow_step1_pipeline_steps_clustering_features_parameters"],
                            "LOOKBACK_SUMS": dc["step1"]["flow_step1_pipeline_steps_clustering_features_lookback_sums"]
                        }
                    }
                },
                "sub_tasks": [],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "Step2",
                    "on_failure": "Rollback"
                }
            },
            {
                "marker": "Step2",
                "class_name": "Step2",
                "description": "This task will allow the user to perform xxxx",
                "cached": dc["step2"]["flow_step2_skip"],
                "task_cfg": {
                    "EXPERIMENT_KEY": dc["step2"]["flow_step2_experiment_key"],
                    "PIPELINE_STEPS": {
                        "CLUSTERING": {
                            "TRANSACTIONS": dc["step2"]["flow_step2_pipeline_steps_clustering_transactions"],
                            "FEATURES": dc["step2"]["flow_step2_pipeline_steps_clustering_features"],
                            "CLUSTERS": dc["step2"]["flow_step2_pipeline_steps_clustering_clusters"],
                            "LOOKBACK_SUMS": dc["step2"]["flow_step2_pipeline_steps_clustering_lookback_sums"]
                        },
                        "THRESHOLDS": {
                            "TRANSACTIONS": dc["step2"]["flow_step2_pipeline_steps_thresholds_transactions"],
                            "PARAMETERS": dc["step2"]["flow_step2_pipeline_steps_thresholds_parameters"],
                            "L2_RECALL_TRAIN": float(dc["step2"]["flow_step2_pipeline_steps_thresholds_l2_recall_train"]),
                            "L2_RECALL_TEST": float(dc["step2"]["flow_step2_pipeline_steps_thresholds_l2_recall_test"]),
                            "LOOKBACK_SUMS": dc["step2"]["flow_step2_pipeline_steps_thresholds_lookback_sums"],
                            "FEATURES": dc["step2"]["flow_step2_pipeline_steps_thresholds_features"]
                        },
                        "ALERTING": {
                            "TRANSACTIONS": dc["step2"]["flow_step2_pipeline_steps_alerting_transactions"],
                            "PROD_ALERTS": dc["step2"]["flow_step2_pipeline_steps_alerting_prod_alerts"],
                            "PROD_ALERTS_KEY": dc["step2"]["flow_step2_pipeline_steps_alerting_prod_alerts_key"],
                            "PARAMETERS": dc["step2"]["flow_step2_pipeline_steps_alerting_parameters"],
                            "LOOKBACK_SUMS": dc["step2"]["flow_step2_pipeline_steps_alerting_lookback_sums"],
                            "THRESHOLDS": dc["step2"]["flow_step2_pipeline_steps_alerting_thresholds"],
                            "ANALYSIS_DATES": dc["step2"]["flow_step2_pipeline_steps_alerting_analysis_dates"]
                        },
                        "KPIS": {
                            "TRANSACTIONS": dc["step2"]["flow_step2_pipeline_steps_kpis_transactions"],
                            "ALERTS": dc["step2"]["flow_step2_pipeline_steps_kpis_alerts"],
                            "BASELINE": dc["step2"]["flow_step2_pipeline_steps_kpis_baseline"],
                            "PARAMETERS": dc["step2"]["flow_step2_pipeline_steps_kpis_parameters"],
                            "ANALYSIS_DATES": dc["step2"]["flow_step2_pipeline_steps_kpis_analysis_dates"]
                        }
                    }
                },
                "sub_tasks": [

                ],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "ManualLock",
                    "on_failure": "Rollback"
                }
            },
            {
                "marker": "ManualLock",
                "class_name": "ManualLock",
                "description": "This task will allow the user to perform xxxx",
                "cached": False,
                "task_cfg": {},
                "sub_tasks": [],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "Step3",
                    "on_failure": "end"
                }
            },
            {
                "marker": "Step3",
                "class_name": "Step3",
                "description": "This task will allow the user to perform xxxx",
                "cached": dc["step3"]["flow_step3_skip"],
                "task_cfg": {
                    "EXPERIMENT_KEY": dc["step3"]["flow_step3_experiment_key"],
                    "PIPELINE_STEPS": {
                        "CLUSTERING": {
                            "TRANSACTIONS": dc["step3"]["flow_step3_pipeline_steps_clustering_transactions"],
                            "FEATURES": dc["step3"]["flow_step3_pipeline_steps_clustering_features"],
                            "CLUSTERS": dc["step3"]["flow_step3_pipeline_steps_clustering_clusters"],
                            "LOOKBACK_SUMS": dc["step3"]["flow_step3_pipeline_steps_clustering_lookback_sums"],
                        },
                        "THRESHOLDS": {
                            "TRANSACTIONS": dc["step3"]["flow_step3_pipeline_steps_thresholds_transactions"],
                            "PARAMETERS": dc["step3"]["flow_step3_pipeline_steps_thresholds_parameters"],
                            "L2_RECALL_TRAIN": float(dc["step3"]["flow_step3_pipeline_steps_thresholds_l2_recall_train"]),
                            "L2_RECALL_TEST": float(dc["step3"]["flow_step3_pipeline_steps_thresholds_l2_recall_test"]),
                            "LOOKBACK_SUMS": dc["step3"]["flow_step3_pipeline_steps_thresholds_lookback_sums"],
                            "FEATURES": dc["step3"]["flow_step3_pipeline_steps_thresholds_features"],
                        },
                        "ALERTING": {
                            "TRANSACTIONS": dc["step3"]["flow_step3_pipeline_steps_alerting_transactions"],
                            "PROD_ALERTS": dc["step3"]["flow_step3_pipeline_steps_alerting_prod_alerts"],
                            "PROD_ALERTS_KEY": dc["step3"]["flow_step3_pipeline_steps_alerting_prod_alerts_key"],
                            "PARAMETERS": dc["step3"]["flow_step3_pipeline_steps_alerting_parameters"],
                            "LOOKBACK_SUMS": dc["step3"]["flow_step3_pipeline_steps_alerting_lookback_sums"],
                            "THRESHOLDS": dc["step3"]["flow_step3_pipeline_steps_alerting_thresholds"],
                            "ANALYSIS_DATES": dc["step3"]["flow_step3_pipeline_steps_alerting_analysis_dates"],
                        },
                        "KPIS": {
                            "TRANSACTIONS": dc["step3"]["flow_step3_pipeline_steps_kpis_transactions"],
                            "ALERTS": dc["step3"]["flow_step3_pipeline_steps_kpis_alerts"],
                            "BASELINE": dc["step3"]["flow_step3_pipeline_steps_kpis_baseline"],
                            "PARAMETERS": dc["step3"]["flow_step3_pipeline_steps_kpis_parameters"],
                            "ANALYSIS_DATES": dc["step3"]["flow_step3_pipeline_steps_kpis_analysis_dates"],
                        },
                        "FILES_EXPORT": {
                            "FEATURES": dc["step3"]["flow_step3_pipeline_steps_files_export_features"],
                            "THRESHOLDS": dc["step3"]["flow_step3_pipeline_steps_files_export_thresholds"],
                            "PARAMETERS": dc["step3"]["flow_step3_pipeline_steps_files_export_parameters"],
                            "TRANSACTIONS": dc["step3"]["flow_step3_pipeline_steps_files_export_transactions"],
                            "CLUSTERS": dc["step3"]["flow_step3_pipeline_steps_files_export_clusters"],
                            "ALERTS": dc["step3"]["flow_step3_pipeline_steps_files_export_alerts"]
                        }
                    },
                },
                "sub_tasks": [],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "Step4",
                    "on_failure": "Rollback"
                }
            },
            {
                "marker": "Step4",
                "class_name": "Step4",
                "description": "This task will allow the user to perform xxxx",
                "cached": dc["step4"]["flow_step4_skip"],
                "task_cfg": {
                    "EXPERIMENT_KEY": dc["step4"]["flow_step4_experiment_key"],
                    "CLUSTER_KEY": dc["step4"]["flow_step4_cluster_key"],
                    "PIPELINE_STEPS": {
                        "DATA_SERIALIZATION": {
                            "ALERTS_SERIALISATION": dc["step4"][
                                "flow_step4_pipeline_steps_data_serialization_alerts_serialisation"],
                            "TRANSACTIONS_SERIALISATION": dc["step4"][
                                "flow_step4_pipeline_steps_data_serialization_transactions_serialisation"],
                            "AMLIT_ALERTS_SERIALISATION": dc["step4"][
                                "flow_step4_pipeline_steps_data_serialization_amlit_alerts_serialisation"],
                            "LOOKBACK_SUMS": dc["step4"]["flow_step4_pipeline_steps_data_serialization_lookback_sums"]
                        },
                        "ALERTING": {
                            "TRANSACTIONS": dc["step4"]["flow_step4_pipeline_steps_alerting_transactions"],
                            "PROD_ALERTS": dc["step4"]["flow_step4_pipeline_steps_alerting_prod_alerts"],
                            "PROD_ALERTS_KEY": dc["step4"]["flow_step4_pipeline_steps_alerting_prod_alerts_key"],
                            "PARAMETERS": dc["step4"]["flow_step4_pipeline_steps_alerting_parameters"],
                            "LOOKBACK_SUMS": dc["step4"]["flow_step4_pipeline_steps_alerting_lookback_sums"],
                            "THRESHOLDS": dc["step4"]["flow_step4_pipeline_steps_alerting_thresholds"],
                            "ANALYSIS_DATES": dc["step4"]["flow_step4_pipeline_steps_alerting_analysis_dates"]
                        },
                        "KPIS": {
                            "TRANSACTIONS": dc["step4"]["flow_step4_pipeline_steps_kpis_transactions"],
                            "ALERTS": dc["step4"]["flow_step4_pipeline_steps_kpis_alerts"],
                            "BASELINE": dc["step4"]["flow_step4_pipeline_steps_kpis_baseline"],
                            "PARAMETERS": dc["step4"]["flow_step4_pipeline_steps_kpis_parameters"],
                            "ANALYSIS_DATES": dc["step4"]["flow_step4_pipeline_steps_kpis_analysis_dates"]
                        }
                    }
                },
                "sub_tasks": [],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "Step5",
                    "on_failure": "Rollback"
                }
            },
            {
                "marker": "Step5",
                "class_name": "Step5",
                "description": "This task will allow the user to perform xxxx",
                "cached": dc["step5"]["flow_step5_skip"],
                "task_cfg": {
                    "EXPERIMENT_KEY": dc["step5"]["flow_step5_experiment_key"],
                    "PIPELINE_STEPS": {
                        "FILES_EXPORT": {
                            "FEATURES": dc["step5"]["flow_step5_pipeline_steps_files_export_features"],
                            "THRESHOLDS": dc["step5"]["flow_step5_pipeline_steps_files_export_thresholds"],
                            "PARAMETERS": dc["step5"]["flow_step5_pipeline_steps_files_export_parameters"],
                            "TRANSACTIONS": dc["step5"]["flow_step5_pipeline_steps_files_export_transactions"],
                            "CLUSTERS": dc["step5"]["flow_step5_pipeline_steps_files_export_clusters"],
                            "ALERTS": dc["step5"]["flow_step5_pipeline_steps_files_export_alerts"]
                        }
                    }
                },
                "sub_tasks": [],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "end",
                    "on_failure": "Rollback"
                }
            },
            {
                "marker": "Rollback",
                "class_name": "Rollback",
                "description": "This task will allow the user to perform xxxx",
                "cached": False,
                "task_cfg": {
                    "DELETE_INPUT_CACHE": dc["rollback"]["flow_rollback_delete_input_cache"],
                    "DELETE_KYC_CACHE": dc["rollback"]["flow_rollback_delete_kyc_cache"],
                    "DELETE_OUTPUT_CACHE": dc["rollback"]["flow_rollback_delete_output_cache"]
                },
                "sub_tasks": [],
                "slots": {
                    "custom_slots": [
                    ],
                    "on_success": "end",
                    "on_failure": "end"
                }
            }
        ]
    }
