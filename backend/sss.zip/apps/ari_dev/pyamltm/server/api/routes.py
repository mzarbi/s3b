import json
import shutil
from datetime import datetime, date, timedelta
from os.path import exists
from threading import Lock, current_thread
import os

import flask
from flask import Blueprint, request, jsonify, send_file

from flow_manager.manifest import ManifestDB, Query
from flow_manager.models.flow_model import flow_model_from_dict
from flow_manager.persistqueue import FIFOSQLiteQueue
from flow_manager.struct.abstract_executor import CustomThreadPoolExecutor
from flow_manager.utils.pycore_extensions import S3ManagerExtension
from server.api.commons import build_flow, path_to_dict, getLogs
from server.broadcaster import MessageAnnouncer

api_blueprint = Blueprint("api", __name__, url_prefix=f'/{os.environ["BRANCH"][1:]}/api')
executor = CustomThreadPoolExecutor(max_workers=3, lock=Lock())

broadcaster = MessageAnnouncer()


def load_manifest():
    manifest_path = os.environ["CACHE_PATH"] + "/" + "manifest.json"
    return ManifestDB(manifest_path)


@api_blueprint.route('/listen', methods=['GET'])
def listen():
    def stream():
        messages = broadcaster.listen()  # returns a queue.Queue
        while True:
            msg = messages.get()  # blocks until a new message arrives
            yield msg

    return flask.Response(stream(), mimetype='text/event-stream')


@api_blueprint.route('/ping')
def ping():
    msg = format_sse(data='pong')
    broadcaster.announce(msg=msg)
    return {}, 200


def format_sse(data: str, event=None) -> str:
    msg = f'data: {data}\n\n'
    if event is not None:
        msg = f'event: {event}\n{msg}'
    return msg


@api_blueprint.route("/tasks", methods=["POST"])
def run_flow():
    try:
        bucketsFile = request.files["bucketsFile"]
    except:
        bucketsFile = None

    try:
        thresholdParametersFile = request.files["thresholdParametersFile"]
    except:
        thresholdParametersFile = None

    flow_specs = flow_model_from_dict(build_flow(json.loads(request.form["flow_specs"])))
    thread = current_thread()
    uuid = executor.register_flow(
        flow_specs,
        new_flow=False if request.form["isNew"] == "false" else True,
        uuid=request.form["uuid"],
        buckets_file=bucketsFile,
        threshold_parameters_file=thresholdParametersFile
    )
    return jsonify({"task_id": uuid}), 202


@api_blueprint.route("/admin-msg", methods=["GET"])
def admin_msg():
    return jsonify({
        "message": "Welcome to AML Flow Manager"
    }), 202


@api_blueprint.route("/notifications", methods=["GET"])
def notifications():
    q = FIFOSQLiteQueue(
        os.path.join(os.environ["CACHE_PATH"], "notifications"),
        auto_commit=True, multithreading=True
    )
    if q.qsize() == 0:
        return jsonify({
            "message": "",
            "status": "NOTHING"
        }), 202
    return jsonify(q.get(timeout=1)), 202


@api_blueprint.route("/archives", methods=["GET"])
def fetch_archives():
    s3 = S3ManagerExtension('gb', 'dev', 'raw')
    return jsonify(s3.read_manifest()["flows"]), 202


@api_blueprint.route("/task/archive/<task_id>", methods=["GET"])
def make_archives(task_id):
    if task_id == "undefined":
        return jsonify({
            "message": "Archiving finished with error"
        }), 202

    s3 = S3ManagerExtension('gb', 'dev', 'raw')
    ls = load_manifest().search(Query().uuid == task_id)
    ls = ls[0] if len(ls) > 0 else {}
    if ls != {}:
        s3.push(
            task_id,
            ls["business_unit"],
            ls["name"]
        )

        load_manifest().remove(Query().uuid == task_id)
        return jsonify({
            "message": "Archiving finished with success"
        }), 202

    return jsonify({
        "message": "Archiving finished with error"
    }), 202


@api_blueprint.route("/task/restore/<bu>/<task_id>", methods=["GET"])
def restore_archives(bu, task_id):
    if task_id == "undefined":
        return jsonify({
            "message": "Archiving finished with error"
        }), 202

    s3 = S3ManagerExtension('gb', 'dev', 'raw')
    s3.pull(task_id, bu)
    with open(os.path.join(os.environ["CACHE_PATH"],task_id,"flow.json"),"r") as f:
        model = flow_model_from_dict(json.load(f))

    load_manifest().insert({
        'uuid': task_id,
        "name": model.flow_cfg["NAME"],
        "description": model.flow_cfg["DESCRIPTION"],
        "business_unit": bu,
        'state': 'SUBMITTED',
        "breakpoints": [],
        'start': datetime.now().strftime("%m-%d-%Y %H:%M:%S")
    })
    return jsonify({
        "message": "Archiving finished with error"
    }), 202


@api_blueprint.route("/tasks", methods=["GET"])
def fetch_tasks():
    return jsonify([{
        "uuid": f["uuid"],
        "name": f["name"],
        "description": f["description"],
        "business_unit": f["business_unit"],
        "start": f.get("start", ""),
        "end": f.get("end", ""),
        "state": f.get("state", "")
    } for f in load_manifest().all()]), 202


@api_blueprint.route("/tasks/<day>", methods=["GET"])
def fetch_task_within_days(day):
    return jsonify(fetch_tasks_in_last_x_days(day)), 202


def count_active_flows():
    return len(fetch_active_flows())


def fetch_active_flows():
    def query(task):
        try:
            if task.get("state", "") != "SUCCESS":
                return True
            return False
        except:
            return False

    return [{
        "uuid": f["uuid"],
        "start": f.get("start", ""),
        "end": f.get("end", ""),
        "state": f.get("state", "")
    } for f in load_manifest().all() if query(f)]


def count_tasks_in_last_x_days(day):
    return len(fetch_tasks_in_last_x_days(day))


def fetch_tasks_in_last_x_days(day):
    def date_within_range(task, day):
        date_str = task['start']

        date_ = datetime.strptime(date_str, "%m-%d-%Y %H:%M:%S")
        today = date.today()

        margin = timedelta(days=int(day))
        return today - margin <= date_.date()

    return [{
        "uuid": f["uuid"],
        "start": f.get("start", ""),
        "end": f.get("end", ""),
        "state": f.get("state", "")
    } for f in load_manifest().all() if date_within_range(f, day)]


@api_blueprint.route("/task/raw/<task_id>", methods=["GET"])
def task(task_id):
    ls = load_manifest().search(Query().uuid == task_id)
    ls = ls[0] if len(ls) > 0 else {}
    return jsonify(ls), 202


@api_blueprint.route("/task/delete/<task_id>", methods=["GET"])
def delete_task(task_id):
    if task_id == "undefined":
        return jsonify([]), 202
    load_manifest().remove(Query().uuid == task_id)
    try:
        shutil.rmtree(os.path.join(os.environ["CACHE_PATH"], task_id))
    except:
        pass
    return jsonify({
        'message': "deleted with success"
    }), 202


@api_blueprint.route("/task/clusters/<task_id>", methods=["GET"])
def clusters(task_id):
    if task_id == "undefined":
        return jsonify([]), 202
    if not os.path.exists(os.path.join(os.environ["CACHE_PATH"], task_id)):
        return jsonify([]), 202
    pth = os.path.join(os.environ["CACHE_PATH"], task_id, "OUTPUT")
    bu = os.listdir(pth)[0]
    with open(os.path.join(pth, bu, "exports", "figures", "clusters_map.json"), "r") as f:
        dc = json.load(f)
    return jsonify(dc), 202


@api_blueprint.route("/check_task/<task_id>", methods=["GET"])
def check_task(task_id):
    if task_id == "undefined":
        return jsonify({
            "status": False
        }), 202

    if not exists(os.path.join(os.environ["CACHE_PATH"], task_id, "flow.json")):
        return jsonify({
            "status": False
        }), 202

    return jsonify({
        "status": True
    }), 202


@api_blueprint.route("/task/sig/<task_id>", methods=["GET"])
def task_signature(task_id):
    def compute_progress(task):
        if task.get("state", "") == "SUCCESS":
            return 100
        else:
            return 0

    ls = [{
        "uuid": f["uuid"],
        "start": f.get("start", ""),
        "end": f.get("end", ""),
        "state": f.get("state", ""),
        "progress": compute_progress(f)
    } for f in load_manifest().search(Query().uuid == task_id)]
    return jsonify(ls[0] if len(ls) > 0 else {}), 200


@api_blueprint.route("/task/breakpoints2/<task_id>", methods=["GET"])
def task_breakpoints2(task_id):
    ls = [[g for g in f.get("breakpoints", [])] for f in load_manifest().search(Query().uuid == task_id)]

    ls = ls[0] if len(ls) > 0 else []
    ls2 = [i for i in ls if i.get("parent", None) is None]
    dc = []
    ls = []
    for i in ls2:
        if i["uuid"] not in dc:
            ls.append(i)
            dc.append(i["uuid"])

    return jsonify(ls), 200


@api_blueprint.route("/task/breakpoints/<task_id>", methods=["GET"])
def task_breakpoints(task_id):
    ls = [[g for g in f.get("breakpoints", [])] for f in load_manifest().search(Query().uuid == task_id)]

    ls = ls[0] if len(ls) > 0 else []
    ls2 = [i for i in ls if i.get("parent", None) is None]
    for i in ls2:
        i.update({
            "sub-breakpoints": [j for j in ls if j.get("parent", None) == i["uuid"]]
        })
    return jsonify(ls2), 200


@api_blueprint.route("/dashboard-chart", methods=["GET"])
def dashboard_chart():
    return jsonify({
        "labels": [
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
        ],
        "datasets": [
            {
                "label": 'All',
                "data": [0, 0, 0, 0, 0, 0, 0, 0, 0],
            },
            {
                "label": 'EFT',
                "data": [0, 0, 0, 0, 0, 0, 0, 0, 0],
            }, {
                "label": 'THV',
                "data": [0, 0, 0, 0, 0, 0, 0, 0, 0],
            },
            {
                "label": 'FTF',
                "data": [0, 0, 0, 0, 0, 0, 0, 0, 0],
            },
        ]
    }), 202


@api_blueprint.route("/dashboard-chart/<task_id>", methods=["GET"])
def flow_dashboard_chart(task_id):
    return jsonify({
        "labels": [
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
        ],
        "datasets": [
            {
                "label": 'All',
                "data": [0, 0, 0, 0, 0, 0, 0, 0, 0],
            },
            {
                "label": 'EFT',
                "data": [0, 0, 0, 0, 0, 0, 0, 0, 0],
            }, {
                "label": 'THV',
                "data": [0, 0, 0, 0, 0, 0, 0, 0, 0],
            },
            {
                "label": 'FTF',
                "data": [0, 0, 0, 0, 0, 0, 0, 0, 0],
            },
        ]
    }), 202


@api_blueprint.route("/fast-kpis/<task_id>", methods=["GET"])
def task_kpis(task_id):
    ls = load_manifest().search(Query().uuid == task_id)
    ls = ls[0] if len(ls) > 0 else {}
    if ls == {}:
        return jsonify({}), 202
    return jsonify([
        {
            "name": ls["state"],
            "value": ls["name"]
        }
    ]), 202


@api_blueprint.route("/file/<file_name>")
def get_file(file_name):
    import base64

    pth = str(base64.b64decode(str(file_name))).replace("\\\\", "\\")

    fl = os.path.join(os.environ["CACHE_PATH"], pth).replace("b'", '').replace("'", '')
    response = send_file(os.path.join(fl), as_attachment=True,
                         attachment_filename=os.path.basename(fl))
    response.headers["x-filename"] = os.path.basename(fl)
    response.headers["Access-Control-Expose-Headers"] = 'x-filename'
    return response


@api_blueprint.route("/file-system/<task_id>", methods=["GET"])
def file_system(task_id):
    flow_path = os.path.join(os.environ["CACHE_PATH"], task_id)
    if os.path.exists(flow_path):
        return jsonify(
            path_to_dict(
                os.path.join(os.environ["CACHE_PATH"], task_id), os.environ["CACHE_PATH"]
            )
        ), 202
    else:
        return jsonify({}), 202


@api_blueprint.route("/logs/<task_id>", methods=["GET"])
def logs(task_id):
    flow_path = os.path.join(os.environ["CACHE_PATH"], task_id, "debug.log")
    if os.path.exists(flow_path):
        return jsonify(
            getLogs(
                os.path.join(os.environ["CACHE_PATH"], task_id, "debug.log")
            )
        ), 202
    else:
        return jsonify({}), 202


@api_blueprint.route("/load-flow-specs/<task_id>", methods=["GET"])
def load_flow_specs(task_id):
    flow_path = os.path.join(os.environ["CACHE_PATH"], task_id, "flow.json")
    dc = {}
    if os.path.exists(flow_path):
        with open(flow_path, "r") as f:
            dc = json.load(f)
    return jsonify({
        "specs": dc
    }), 202


@api_blueprint.route("/fast-kpis", methods=["GET"])
def kpis():
    return jsonify([
        {
            "name": "Active Flows",
            "value": count_active_flows()
        }, {
            "name": "Anomalies Detected",
            "value": 100
        }
    ]), 202


@api_blueprint.route("/gcars-report-list", methods=["GET"])
def get_gcars_report_list():
    return jsonify([
        {
            "name": "gcars_report.csv"
        }
    ]), 202


@api_blueprint.route("/sensitivity-report-list", methods=["GET"])
def get_sensitivity_report_list():
    return jsonify([
        {
            "name": "sensitivity_report.csv"
        }
    ]), 202


@api_blueprint.route("/kyc-reliance-worldwide-report-list", methods=["GET"])
def get_kyc_reliance_worldwide_report_list():
    return jsonify([
        {
            "name": "kyc_reliance_worldwide.csv"
        }
    ]), 202


@api_blueprint.route("/country-risk-report-list", methods=["GET"])
def get_country_risk_report_list():
    return jsonify([
        {
            "name": "country_risk.csv"
        }
    ]), 202


@api_blueprint.route("/actimize-version-list", methods=["GET"])
def get_actimize_version_list():
    return jsonify([
        {
            "name": 3
        },
        {
            "name": 8
        }
    ]), 202


@api_blueprint.route("/models-list", methods=["GET"])
def get_models_list():
    with open(os.path.join(os.environ["RESOURCES_PATH"], "models.json"), "r") as f:
        dc = json.load(f)
    return jsonify(dc), 202


@api_blueprint.route("/business-unit-list", methods=["GET"])
def get_business_unit_list():
    with open(os.path.join(os.environ["RESOURCES_PATH"], "business_units.json"), "r") as f:
        dc = json.load(f)
    return jsonify(dc), 202


@api_blueprint.route("/bucket-mapping-mode-list", methods=["GET"])
def get_bucket_mapping_mode_list():
    return jsonify([
        {
            "name": "ADVANCED"
        },
        {
            "name": "SIMPLE"
        }
    ]), 202
