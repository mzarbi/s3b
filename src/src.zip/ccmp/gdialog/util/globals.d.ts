export declare const IN_BROWSER: boolean;
//# sourceMappingURL=globals.d.ts.map