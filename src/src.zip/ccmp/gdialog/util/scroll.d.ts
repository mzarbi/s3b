/**
 * A copy of the vuetify implemantation
 * https://github.com/vuetifyjs/vuetify/blob/v2.5.8/packages/vuetify/src/mixins/overlayable/index.ts
 */
export declare const noScrollableParent: (event: WheelEvent, content: Element | undefined) => boolean;
export declare const getScrollbarWidth: () => number;
//# sourceMappingURL=scroll.d.ts.map