export declare function convertToUnit(str: number, unit?: string): string;
export declare function convertToUnit(str: string | number | null | undefined, unit?: string): string | undefined;
declare const _default: {
    convertToUnit: typeof convertToUnit;
};
export default _default;
//# sourceMappingURL=helpers.d.ts.map