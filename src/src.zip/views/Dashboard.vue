<template>
    <div class="py-4 container-fluid">
        <h1>Dashboard</h1>
        <div class="col-6 text-end">
            <soft-button color="success" size="sm" variant="outline" @click="onOpen">
                View All
            </soft-button>


            <info-dialog v-model="dialogState">
                <p v-for="i in 10" :key="i">
                    Lorem ipsum dolor sit, amet consectetur
                    adipisicing elit. Voluptatum voluptas laboriosam
                    voluptate ex consequuntur corporis, commodi animi
                    architecto quidem fugiat.
                </p>
            </info-dialog>
            <soft-button color="success" size="sm" variant="outline" @click="dialogState = true">
                View All
            </soft-button>
        </div>
    </div>
</template>
<script>
    import SoftButton from "@/components/SoftButton.vue";
    import {inject, ref} from 'vue'
    import {dialogInjectionKey} from '../ccmp/gdialog/index';
    import ConfirmDialog from "./dialogs/ConfirmDialog";
    import InfoDialog from "./dialogs/InfoDialog";


    export default {
        name: "dashboard-default",
        data() {
            return {};
        },
        components: {
            SoftButton,InfoDialog
        },
        setup() {
            const $dialog = inject(dialogInjectionKey);
            const dialogState = ref(false);

            const onOpen = () => {
                $dialog.addDialog({
                    component: ConfirmDialog,
                    props: {
                        title: 'Hello Zied',
                        message: 'Are you sure you want to .. ?',
                        route: "sample",
                        // eslint-disable-next-line no-unused-vars
                        onOk: (resp) =>{
                            alert(JSON.stringify(resp));
                        },
                        onCancel: () =>{

                        }
                    },
                });
            };
            return {
                onOpen, dialogState
            };
        },
    };
</script>
